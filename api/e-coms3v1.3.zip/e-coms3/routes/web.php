<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
use Spatie\Sitemap\SitemapGenerator;

use Spatie\Sitemap\Tags\Url;

Route::get('/', function () {
    return view('index');
});
Route::get('/index', function () {
    return view('index');
});
Route::get('/about', function () {
    return view('about');
});
Route::get('/contact', function () {
    return view('contact');
});
Route::get('notify', function () {
    return view('notify');
});
Route::get('/welcome', function () {
    return view('welcome');
});

Auth::routes();
//MYcontrollers::routes();

Route::get('/home', 'HomeController@index')->name('home');

Route::get('/recieve', 'CheckOutController@someClass');

Route::get('/som', 'TryController@index');

Route::get('/pay', 'slydepay@index');
Route::get('/paid', 'slydepay\SlydepayController@index');

Route::get('/login1', function () {
    return view('auth/modal');
});




Route::get('/sitemap', function()
{
   return Response::view('sitemap')->header('Content-Type', 'application/xml');
});

/*CheckOutController
Route::get('/sitemap', function () {

    SitemapGenerator::create('http://localhost/2020/e-coms3/pulic/notify')



    ->add(Url::create('/index')->setPriority(0.5))
    ->add(Url::create('/about')->setPriority(0.5))
    ->add(Url::create('/contact')->setPriority(0.5))
    ->add(Url::create('/link3')->setPriority(0.5))
    ->add(Url::create('/notify')->setPriority(0.5))


    ->writeToFile('sitemap.xml');

    return "sitemap created";
});
-}
*/
