<?php


/*


<!-- Button trigger modal -->


  <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalCenter">
    Launch demo modal
  </button>

  <!-- Modal -->
  <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLongTitle">Modal title</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
            <img class="d-block w-100" src="img/banner-2.jpg" alt="">
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="button" class="btn btn-primary">Save changes</button>
        </div>
      </div>
    </div>
  </div>
*/


require '../vendor/autoload.php';

use Slydepay\Order\Order;
use Slydepay\Order\OrderItem;
use Slydepay\Order\OrderItems;

// Instantiate Slydepay
$slydepay = new Slydepay\Slydepay("yeboah.determined.isaac@gmail.com", "173836");

// Create a list of OrderItems with OrderItem objects
$orderItems = new OrderItems([
    new OrderItem("1234", "Test Product", 10, 2),
    new OrderItem("1284", "Test Product2", 20, 2),
]);

// Shipping and tax pulled either from ini/properties file. Hard coded here for illustration
$shippingCost = 20;
$tax = 10;

// Create the Order object for this transaction.
$order = Order::createWithId(
    $orderItems,
    "order_id_1",
    $shippingCost,
    $tax,
    "description",
    "no comment"
);

try {
    // Make request to Slydepay and get the response object for the redirect url
    $response = $slydepay->processPaymentOrder($order);
    echo $response->redirectUrl();
} catch (Slydepay\Exception\ProcessPayment $e) {
    echo $e->getMessage();
}
