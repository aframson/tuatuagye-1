<?php $__env->startSection('content'); ?>

<h1>about</h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\isaac\htdocs\2020\e-coms3\resources\views/about.blade.php ENDPATH**/ ?>