<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
        xmlns:image="http://www.google.com/schemas/sitemap-image/1.1"
        xmlns:video="http://www.google.com/schemas/sitemap-video/1.1">
    <?php $__currentLoopData = Cache::get('sitemap'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $url => $params): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <url>
        <loc><?php echo e($url); ?></loc>
        <lastmod><?php echo e($params['lastmod']); ?></lastmod>
        <changefreq><?php echo e($params['changefreq']); ?></changefreq>
        <priority><?php echo e($params['priority']); ?></priority>
    </url>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</urlset>
<?php /**PATH C:\xampp\isaac\htdocs\2020\e-coms3\resources\views/sitemap.blade.php ENDPATH**/ ?>