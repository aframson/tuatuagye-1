    <!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-PY66NSKPP7"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-PY66NSKPP7');
  function openForm() {
      document.getElementById("thebutton").style.display ="none";
document.getElementById("myForm").style.display = "block";
}

function closeForm() {

  document.getElementById("myForm").style.display = "none";
  document.getElementById("thebutton").style.display ="block";
  document.getElementById("1_ModalCenter").style.display ="none";


}

</script>
<?php /**PATH C:\xampp\isaac\htdocs\2020\e-coms3\resources\views/master/content/google.blade.php ENDPATH**/ ?>