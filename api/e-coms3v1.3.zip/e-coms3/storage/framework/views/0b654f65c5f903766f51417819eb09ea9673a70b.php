 <!-- Button trigger modal -->
<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalCenter" style="display:none">
    Launch welcome discount banner
  </button>

  <!-- Modal -->
  <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
      <div class="modal-content"  style="height: auto;">

        <div class="modal-body">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"style="
                    position: absolute;
                    right: 2%;
                    z-index: 50;">

                <span class="hide" aria-hidden="true">&times;</span>
              </button>
            <img class="d-block w-100" src="img/web-banner.jpg" alt="" style="z-index:100000;">

                 <div class=" text-center" style="height: 0px;">
                        <!--<button type="button" class="btn btn-light" style="display:none;  z-index: 200; position: relative; margin-top: -30%;">tuatuagye</button>
                        <button type="button" class="btn btn-primary" style="z-index: 200; display:none;    position: relative;margin-top: -30%;">tuatuagye</button>  -->
                    </div>
        </div>

      </div>
    </div>
  </div>


<!-- pop up chat begins -->
<!-- pop up chat begins -->


<?php /**PATH C:\xampp\isaac\htdocs\2020\e-coms3\resources\views/master/content/popup.blade.php ENDPATH**/ ?>