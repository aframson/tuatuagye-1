<div class="stretch">
<style>


</style>
<button>black</button>

</div>

<div class="navbar-default">

    <!-- Static navbar -->
    <nav class="navbar navbar-default">
      <div class="container-fluid">
        <div class="navbar-header">
            <ul class="nav justify-content-center">
                <li class="nav-item">
                    <a class="nav-link active" href="#" style="color:black">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#" style="color:black">About</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#" style="color:black">Contact</a>
                </li>
            </ul>

        </div>

      </div><!--/.container-fluid -->
    </nav>
    </div>

    <hr class="space">
<div class="header-nav">
</div>
    <a class="navbar-brand" href="{{ url('/') }}">
        {{ config('app.name', 'TuaTuaGye') }}
    </a>
    <nav class="navbar navbar-default">
        <div class="container">
        </div>
    </nav>


</div>
            </a>
            <img src="{{ URL::asset("/img/logo.png") }}" alt="" class="logo">
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="{{ __('Toggle navigation') }}">
                <span class="navbar-toggler-icon"></span>
            </button>
<div class= "bg-image" style="backround-image: url(img/carpet.jpg)">

</div>

        <form action="#" id="searcj">
        <input type="text" id="search">
        <button class="btn  stretch ">search</button>
        </form>
    </nav>



























    @extends('master.layout')



@section('content')
<head>

     <!-- Css Styles -->
     <!-- navbar search area -->
     <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
     <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
     <link rel="stylesheet" href="css/themify-icons.css" type="text/css">
     <link rel="stylesheet" href="css/elegant-icons.css" type="text/css">
     <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
     <link rel="stylesheet" href="css/nice-select.css" type="text/css">
     <link rel="stylesheet" href="css/jquery-ui.min.css" type="text/css">
     <link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
     <link rel="stylesheet" href="css/style.css" type="text/css">
     <link rel="stylesheet" href="css/home.css" type="text/css">
     <link rel="stylesheet" href="css/header.css" type="text/css">

     <!-- jquery ui -->
     <link href="css/jquery-ui.css" rel="stylesheet">
     <link href="css/jquery-ui.min.css" rel="stylesheet">
     <link href="css/jquery-ui.structure.css" rel="stylesheet">
     <link href="css/jquery-ui.structure.min.css" rel="stylesheet">
     <link href="css/jquery-ui.theme.css" rel="stylesheet">
     <link href="css/jquery-ui.theme.min.css" rel="stylesheet">

     <!-- alibaba-->
     <link rel='dns-prefetch' href='//s.alicdn.com'>
     <link rel='dns-prefetch' href='//i.alicdn.com'>
     <link rel='dns-prefetch' href='//b.alicdn.com'>
     <link rel='dns-prefetch' href='//is.alicdn.com'>
     <link rel='dns-prefetch' href='//u.alicdn.com'>
     <link rel='dns-prefetch' href='//g.alicdn.com'>
     <link rel='dns-prefetch' href='//assets.alicdn.com'>
     <link rel='dns-prefetch' href='//img.alicdn.com'>
     <link rel='dns-prefetch' href='//cmap.alibaba.com'>
     <link rel='dns-prefetch' href='//activity.alibaba.com'>
     <link rel='dns-prefetch' href='//gj.mmstat.com'>
     <link rel='dns-prefetch' href='//go.mmstat.com'>
     <link rel='dns-prefetch' href='//dmtracking2.alibaba.com'>
     <link rel='dns-prefetch' href='//profile.alibaba.com'>
     <link rel='dns-prefetch' href='//notification.alibaba.com'>

  <!-- jumian -->
    <link rel="stylesheet" href="css/jumia.css">


               <!-- font-awesome -->
     <link rel=“stylesheet” href=“https://use.fontawesome.com/releases/v5.5.0/css/all.css” integrity=“sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU” crossorigin=“anonymous”>



  <!-- carousel -->
     <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</head>
<body>












<div class="aliexpress-notice" id="j-aliexpress-notice" style="display:none;">
	<div class="site-notice-container container">
		<div class="notice-content">By continuing to use Tuatuagye.com you accept our use of cookies (view more on our Privacy Policy). You can adjust your Cookie Preferences at the bottom of this page.</div>
		<a class="notice-close" data-role="close" href="javascript:;">Close</a></div>
</div>
<link href="//i.alicdn.com/ae-header/20191217202516/buyer/glofront/ae-header.css" rel="stylesheet" type="text/css" />
<div class="site-download-header" data-spm="100067" id="j-site-download-header" style="display:none;"><a href="https://itunes.apple.com/app/aliexpress-for-ipad/id854356557"><img data-src="//ae01.alicdn.com/kf/HTB1tEHzb.gQMeJjy0Ff762ddXXaF.png" /></a></div>

<div class="top-lighthouse" data-spm="1000001" id="top-lighthouse">
	<div class="top-lighthouse-wrap container">
		<div class="nav-global" id="nav-global">
			<div class="ng-item-wrap ng-item ng-setting-proxy" data-role="privacy-setting" style="display:none;"><a href="//sale.aliexpress.com/pp-setting.htm">Cookie Preferences</a></div>

			<div class="ng-item-wrap ng-help-wrap">
				<div class="ng-item ng-help ng-sub"><span class="ng-sub-title">Help</span>
					<ul class="ng-sub-list">
						<li><a class="ng-help-link" data-role="help-center-link" href="#" rel="follow">Customer Service</a></li>
						<li><a data-role="complaint-link" href="#" rel="nofollow">Disputes & Reports</a></li>
						<li><a data-role="ipp-link" href="#" rel="nofollow">Report IPR infringement</a></li>
					</ul>
				</div>



				<div class="ng-item ng-mobile"><a href="#" rel="nofollow">App</a></div>
			</div>

			<div class="ng-item-wrap ng-item ng-switcher" data-role="region-pannel"><!-- switcher start -->
				<div data-role="region-pannel"><a class="switcher-info notranslate" data-role="menu" href="#" id="switcher-info" rel="nofollow">&nbsp;</a>

					<div class="switcher-sub notranslate" data-role="content">
						<div class="switcher-common">
							<div class="switcher-shipto item util-clearfix"><span class="label">Ship to</span>

								<div class="country-selector switcher-shipto-c" data-role="switch-country"></div>
							</div>

							<div class="switcher-language item util-clearfix"><span class="label">Language</span></div>

							<div class="switcher-currency item util-clearfix"><span class="label">Currency</span>

								<div class="switcher-currency-c" data-role="switch-currency"></div>
							</div>

							<div class="switcher-btn item util-clearfix"><button class="ui-button ui-button-primary go-contiune-btn" data-role="save" type="button">Save</button></div>
						</div>
					</div>
				</div>
				<!-- switcher end --></div>

			<div class="ng-item-wrap ng-personal-info">
				<div class="ng-item nav-pinfo-item nav-cart nav-cart-box"><a href="#" rel="nofollow"><i class="ng-cart-icon ng-icon-size"></i><span class="text">Cart</span> <span class="cart-number" id="nav-cart-num"></span> </a></div>

				<div class="ng-item nav-pinfo-item nav-wishlist"><a href="#" rel="nofollow"><i class="ng-wishlist-icon ng-icon-size"></i><span class="text">Wish List</span> </a></div>

				<div class="ng-item nav-pinfo-item nav-user-account" id="nav-user-account"><span class="user-account-port"><a data-role="myaliexpress-link" href="#"><i class="ng-account-icon ng-icon-size"></i><span class="text">Account</span> </a> </span>

					<div class="user-account-main" data-role="user-account-main">
						<div class="flyout-user-signIn flyout-new-user" data-role="user-signIn" style="display: block;">
							<p class="flyout-welcome-wrap">Welcome to Tuatuagye</p>

							<div class="flyout-logined"><i class="flyout-user-avatar"><img alt="" data-role="avatar-img" src="" /></i>

								<p class="flyout-welcome-text" data-role="flyout-welcome">Welcome back</p>
							</div>

							<p class="flyout-sign-out" data-role="signout-btn"><a href="#" rel="nofollow">Sign Out</a></p>

							<p class="flyout-bottons"><a class="join-btn" data-role="join-link" href="javaScript:;" rel="nofollow">Join</a> <a class="sign-btn" data-role="sign-link" href="#" rel="nofollow" style="margin:0;">Sign in</a></p>
						</div>
						<i class="flyout-line">&nbsp;</i>
						<ul class="flyout-quick-entry" data-role="quick-entry">
							<li><a href="#" rel="nofollow">My Orders</a></li>
							<li><a href="#" rel="nofollow">Message Center<span class="unread-message-count"></span></a></li>
							<li><a href="#" rel="nofollow">Wish List</a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<link href="//i.alicdn.com/ae-header/20200213195227/buyer/front/ae-header.css" rel="stylesheet" type="text/css" />
<div class="site-download-header" data-spm="100067" id="j-site-download-header" style="display:none;"><a href="https://itunes.apple.com/app/aliexpress-for-ipad/id854356557"><img src="//ae01.alicdn.com/kf/HTB1tEHzb.gQMeJjy0Ff762ddXXaF.png" /></a></div>

<div class="top-lighthouse" data-spm="1000001" id="top-lighthouse">
	<div class="top-lighthouse-wrap container">
		<div class="nav-global" id="nav-global">
			<div class="ng-item ng-setting-proxy" data-role="privacy-setting" style="display:none;"><a href="//sale.aliexpress.com/pp-setting.htm">Cookie Preferences</a></div>

			<div class="ng-item ng-bp"><a href="//sale.aliexpress.com/v8Yr8f629D.htm" rel="nofollow">Buyer Protection</a></div>

			<div class="ng-item ng-help ng-sub"><span class="ng-sub-title">Help</span>
				<ul class="ng-sub-list">
					<li><a class="ng-help-link" data-role="help-center-link" href="//service.aliexpress.com/page/home?pageId=17&language=en" rel="follow">Customer Service</a></li>
					<li><a data-role="complaint-link" href="//report.aliexpress.com" rel="nofollow">Disputes & Reports</a></li>
					<li><a data-role="ipp-link" href="//ipp.alibabagroup.com/index.htm" rel="nofollow">Report IPR infringement</a></li>
				</ul>
			</div>

			<div class="ng-item ng-mobile"><a href="//sale.aliexpress.com/download_app_guide.htm" rel="nofollow">Save big on our app!</a></div>
		</div>
	</div>
</div>

<script crossorigin="anonymous" defer="defer" src="//i.alicdn.com/ae-header/20200213195227/buyer/front/ae-header.js"></script>
<!--ams-region-end 580-->

<div class="header header-outer-container header-special-container" id="header" data-spm="1000002">
    <div class="header-wrap container">
                    <div class="hm-left">
                    <div class="header-categories" id="header-categories">
                <span class="categories-title">CATEGORIAS</span>
                <i class="balloon-arrow"></i>
            </div>
                        <div class="site-logo">
                                <a href="//www.aliexpress.com/"><span class="logo-base">AliExpress</span><span class="logo-slogan">Smarter Shopping, Better Living!</span></a>
                            </div>
                    </div>
        <div class="hm-right">
        	                        <!--ams-region-start 570-->
<div class="nav-cart nav-cart-box"><a href="//shoppingcart.aliexpress.com/shopcart/shopcartDetail.htm" rel="nofollow"><span class="text hidden-sm">Cart</span></a><span class="cart-number" id="nav-cart-num">0</span></div>

<div class="nav-wishlist"><a href="//my.aliexpress.com/wishlist/wish_list_product_list.htm" rel="nofollow"><span class="text hidden-sm">Wish List</span></a></div>

<div class="nav-user-account" id="nav-user-account">
	<div class="user-account-info" data-role="user-account-top">
		<div class="user-account-inner hidden-sm"><span class="account-unsigned" data-role="unsigned"><a data-role="sign-link" href="//login.aliexpress.com/express/mulSiteLogin.htm" rel="nofollow">Sign in</a><span class="ua-line">|</span><a data-role="join-link" href="//login.aliexpress.com/join/buyer/expressJoin.htm" rel="nofollow">Join</a></span> <span class="account-name" data-role="username">&nbsp;</span>

			<div class="myaliexpress" data-role="myaliexpress"><span data-role="myaliexpress-link">My AliExpress</span><b>(0)</b></div>
		</div>
	</div>

	<div class="user-account-main" data-role="user-account-main">
		<div class="flyout-user-signout" data-role="signout-btn"><a href="//login.aliexpress.com/xman/xlogout.htm" rel="nofollow">Sign Out</a></div>

		<div class="flyout-user-signIn" data-role="user-signIn">
			<p class="flyout-welcome-text" data-role="flyout-welcome"></p>

			<p><a class="sign-btn" data-role="sign-link" href="//login.aliexpress.com/express/mulSiteLogin.htm" rel="nofollow">Sign in</a></p>

			<p class="flyout-signIn-type"><span>Sign in with</span> <a class="nus-icon nus-facebook" data-role="login-type" href="//thirdparty.aliexpress.com/login.htm?type=fb&tracelog=ws_fb_topbar" rel="nofollow" title="facebook">&nbsp;</a> <a class="nus-icon nus-vk" data-role="login-type" href="//thirdparty.aliexpress.com/login.htm?type=vk&tracelog=ws_vk_topbar" rel="nofollow" title="vk">&nbsp;</a> <a class="nus-icon nus-google" data-role="login-type" href="//thirdparty.aliexpress.com/login.htm?type=gg&tracelog=ws_gg_mainlogin" rel="nofollow" title="google">&nbsp;</a></p>
		</div>
		<dl class="flyout-visitors-login" data-role="user-login">
			<dt>New Customer?</dt>
			<dd><a class="join-btn" data-role="join-link" href="//login.aliexpress.com/join/buyer/expressJoin.htm" rel="nofollow">Join Free</a></dd>
		</dl>
		<div class="flyout-remind-list" id="flyout-remind-list"></div>
		<ul class="flyout-quick-entry" data-role="quick-entry">
			<li><a href="//home.aliexpress.com/index.htm?tracelog=ws_topbar" rel="nofollow">My AliExpress</a></li>
			<li><a href="//trade.aliexpress.com/orderList.htm?tracelog=ws_topbar" rel="nofollow">My Orders</a></li>
			<li><a href="//msg.aliexpress.com?tracelog=ws_topbar" rel="nofollow">Message Center</a></li>
			<li><a href="//my.aliexpress.com/wishlist/wish_list_product_list.htm" rel="nofollow">Wish List</a></li>
			<li><a class="js-menu-my-favorite-stores" href="//my.aliexpress.com/wishlist/wish_list_store_list.htm" rel="nofollow">My Favorite Stores</a></li>
			<li><a href="//coupon.aliexpress.com/buyer/coupon/listView.htm" rel="nofollow">My Coupons</a></li>
		</ul>
	</div>
</div>

    <!-- Header Section Begin -->
    <header class="header-section">
        <div class="header-top">
            <div class="container">
                <div class="ht-left">
                    <div class="mail-service">
                        <i class=" fa fa-envelope"></i>
                        info@tuatuagye.com
                    </div>
                    <div class="phone-service">
                        <i class=" fa fa-phone"></i>
                        +233 277500001
                    </div>
                </div>
                <div class="ht-right">
                    <a href="#" class="login-panel"><i class="fa fa-user"></i>Login</a>
                    <div class="lan-selector">
                        <select class="language_drop" name="countries" id="countries" style="width:300px;">
                            <option value='yt' data-image="img/flag-1.jpg" data-imagecss="flag yt"
                                data-title="English">English</option>
                            <option value='yu' data-image="img/flag-2.jpg" data-imagecss="flag yu"
                                data-title="Bangladesh">German </option>
                        </select>
                    </div>
                    <div class="top-social">
                        <a href="#"><i class="ti-facebook"></i></a>
                        <a href="#"><i class="ti-twitter-alt"></i></a>
                        <a href="#"><i class="ti-linkedin"></i></a>
                        <a href="#"><i class="ti-pinterest"></i></a>
                    </div>
                </div>
            </div>
        </div>


        <div class="container">
            <div class="inner-header">
                <div class="row">
                    <div class="col-lg-2 col-md-2">
                        <div class="logo1" style="
                            max-height:100px;
                           max-width:100px;


                           left: 0%;
                           ">
                            <a href="#">
                                <img src="img/logo1.png" alt="">
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-7 col-md-7">
                        <div class="advanced-search">
                            <button type="button" class="category-btn">All Categories</button>
                            <div class="input-group">
                                <input type="text" placeholder="What do you need?">
                                <button type="button" style="background-color: rgb(49, 143, 143)"><i class="ti-search" ></i></button>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3 text-right col-md-3">
                        <ul class="nav-right">
                            <li class="heart-icon">
                                <a href="#">
                                    <i class="icon_heart_alt"></i>
                                    <span>1</span>
                                </a>
                            </li>
                            <li class="cart-icon">
                                <a href="#">
                                    <i class="icon_bag_alt"></i>
                                    <span>3</span>
                                </a>
                                <div class="cart-hover">
                                    <div class="select-items">
                                        <table>
                                            <tbody>
                                                <tr>
                                                    <td class="si-pic"><img src="img/select-product-1.jpg" alt=""></td>
                                                    <td class="si-text">
                                                        <div class="product-selected">
                                                            <p>$60.00 x 1</p>
                                                            <h6>Kabino Bedside Table</h6>
                                                        </div>
                                                    </td>
                                                    <td class="si-close">
                                                        <i class="ti-close"></i>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="si-pic"><img src="img/select-product-2.jpg" alt=""></td>
                                                    <td class="si-text">
                                                        <div class="product-selected">
                                                            <p>$60.00 x 1</p>
                                                            <h6>Kabino Bedside Table</h6>
                                                        </div>
                                                    </td>
                                                    <td class="si-close">
                                                        <i class="ti-close"></i>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                    <div class="select-total">
                                        <span>total:</span>
                                        <h5>$120.00</h5>
                                    </div>
                                    <div class="select-button">
                                        <a href="#" class="primary-btn view-card">VIEW CARD</a>
                                        <a href="#" class="primary-btn checkout-btn">CHECK OUT</a>
                                    </div>
                                </div>
                            </li>
                            <li class="cart-price">$150.00</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

<div class="black">
        <div class="container">
            <div class="inner-header">

                <div class="container my-4">


                    <hr class="my-4">

                    <!--Carousel Wrapper-->
                    <div id="carousel-thumb" class="carousel slide carousel-fade carousel-thumbnails" data-ride="carousel">
                      <!--Slides-->
                      <div class="carousel-inner" role="listbox">
                        <div class="carousel-item active">
                          <img class="d-block w-100" src="https://mdbootstrap.com/img/Photos/Slides/img%20(88).jpg" alt="First slide">
                        </div>
                        <div class="carousel-item">
                          <img class="d-block w-100" src="https://mdbootstrap.com/img/Photos/Slides/img%20(121).jpg" alt="Second slide">
                        </div>
                        <div class="carousel-item">
                          <img class="d-block w-100" src="https://mdbootstrap.com/img/Photos/Slides/img%20(31).jpg" alt="Third slide">
                        </div>
                      </div>
                      <!--/.Slides-->
                      <!--Controls-->
                      <a class="carousel-control-prev" href="#carousel-thumb" role="button" data-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="sr-only">Previous</span>
                      </a>
                      <a class="carousel-control-next" href="#carousel-thumb" role="button" data-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="sr-only">Next</span>
                      </a>
                      <!--/.Controls-->
                      <ol class="carousel-indicators">
                        <li data-target="#carousel-thumb" data-slide-to="0" class="active"> <img class="d-block w-100" src="https://mdbootstrap.com/img/Photos/Others/Carousel-thumbs/img%20(88).jpg"
                            class="img-fluid"></li>
                        <li data-target="#carousel-thumb" data-slide-to="1"><img class="d-block w-100" src="https://mdbootstrap.com/img/Photos/Others/Carousel-thumbs/img%20(121).jpg"
                            class="img-fluid"></li>
                        <li data-target="#carousel-thumb" data-slide-to="2"><img class="d-block w-100" src="https://mdbootstrap.com/img/Photos/Others/Carousel-thumbs/img%20(31).jpg"
                            class="img-fluid"></li>
                      </ol>
                    </div>
                    <!--/.Carousel Wrapper-->

                  </div>
            </div>

            </div>
        </div>
        <div class="nav-item">
            <div class="container">
                <div class="nav-depart">
                    <div class="depart-btn">
                        <i class="ti-menu"></i>
                        <span>Category</span>
                        <ul class="depart-hover">
                            <li class="active"><a href="#">Phones</a></li>
                            <li><a href="#">Laptops</a></li>
                            <li><a href="#">TV</a></li>
                            <li><a href="#">Speaker</a></li>
                            <li><a href="#">Kitchen Appliance</a></li>
                            <li><a href="#">Accessories</a></li>
                            <li><a href="#">Luxury Brands</a></li>

                        </ul>
                    </div>
                </div>

    <!-- Header End -->

  <!--/ Carousel Star /-->


            </div>
        </div>

        <div class="container">

  <h1 class="font-weight-light text-center text-lg-left mt-4 mb-0">shop</h1>

  <hr class="mt-2 mb-5">

  <div class="row text-center text-lg-left">

    <div class="col-lg-3 col-md-4 col-6">
      <a href="#" class="d-block mb-4 h-100">
            <img class="img-fluid img-thumbnail" src="https://source.unsplash.com/pWkk7iiCoDM/400x300" alt="">
          </a>
    </div>
    <div class="col-lg-3 col-md-4 col-6">
      <a href="#" class="d-block mb-4 h-100">
            <img class="img-fluid img-thumbnail" src="https://source.unsplash.com/aob0ukAYfuI/400x300" alt="">
          </a>
    </div>
    <div class="col-lg-3 col-md-4 col-6">
      <a href="#" class="d-block mb-4 h-100">
            <img class="img-fluid img-thumbnail" src="https://source.unsplash.com/EUfxH-pze7s/400x300" alt="">
          </a>
    </div>
    <div class="col-lg-3 col-md-4 col-6">
      <a href="#" class="d-block mb-4 h-100">
            <img class="img-fluid img-thumbnail" src="https://source.unsplash.com/M185_qYH8vg/400x300" alt="">
          </a>
    </div>

  </div>

</div>
<!-- /.container -->

<div class="_new-top-container-bg"></div>


<div class="_new-top-container-bg-bar"></div>
<div id="home-firstscreen" class="home-firstscreen _new-home-firstscreen container">
    <div class="home-firstscreen-main _new-home-firstscreen-main">
        <div class="channel-entrance" data-spm="9">
                                <!--ams-region-start 1202-->
<style type="text/css">.new-user-container .coupon-text {
        font-size: 13px;
    }
</style>
<div class="channel-entrance" data-spm="01002" data-test="noah"><a href="//sale.aliexpress.com/supervaluedeal.htm">SUPER VALUE DEALS <span class="marking"> </span></a><a href="//campaign.aliexpress.com/wow/gf/upr-daily?wh_pid=big_discount_page&wh_weex=true&preDownLoad=true&preInitInstance=rax&_immersiveMode=true&wx_navbar_hidden=true&wx_navbar_transparent=true&wx_statusbar_hidden=true&ignoreNavigationBar=true">Big Discounts </a><a href="//sale.aliexpress.com/affiliate_Select_Coupons.htm">Select Coupons </a><a href="//sale.aliexpress.com/category_homegarden_affliate.htm">Home </a><a href="//sale.aliexpress.com/category_tech_affliate.htm">Tech </a><a href="//sale.aliexpress.com/aff_beauty.htm">Beauty </a></div>
 <!--ams-region-end 1202-->
            </div>

        <!-- category start -->
        <div class="categories">

                                        <!--ams-region-start 500-->
<div class="categories-main new-categories-main categories-main-home" data-role="category-content" data-spm="22">
	<div class="categories-content-title" data-role="exclude"><span>CATEGORIES</span><a href="//www.aliexpress.com/all-wholesale-products.html">See All &gt;</a></div>

	<div class="categories-list-box"><!--ams-region-start 514-->
		<dl class="cl-item cl-item-women" data-role="first-menu" data-spm="101">
			<dt class="cate-name"><span><a href="//www.aliexpress.com/category/100003109/women-clothing-accessories.html"> Women’s Clothing</a></span></dt>
			<dd class="sub-cate" data-path="c-women-content" data-role="first-menu-main"></dd>
		</dl>
		<!--ams-region-end 514--><!--ams-region-start 515-->
		<dl class="cl-item cl-item-men" data-role="first-menu" data-spm="102">
			<dt class="cate-name"><span><a href="//www.aliexpress.com/category/100003070/men-clothing-accessories.html">Men’s Clothing</a></span></dt>
			<dd class="sub-cate" data-path="c-men-content" data-role="first-menu-main"></dd>
		</dl>
		<!--ams-region-end 515--><!--ams-region-start 516-->
		<dl class="cl-item cl-item-phones" data-role="first-menu" data-spm="103">
			<dt class="cate-name"><span><a href="//www.aliexpress.com/category/509/cellphones-telecommunications.html">Phones & Accessories</a></span></dt>
			<dd class="sub-cate" data-path="c-phones-content" data-role="first-menu-main"></dd>
		</dl>
		<!--ams-region-end 516--><!--ams-region-start 517-->
		<dl class="cl-item cl-item-computer" data-role="first-menu" data-spm="104">
			<dt class="cate-name"><span><a href="//www.aliexpress.com/category/7/computer-office.html">Computer</a>, <a href="//www.aliexpress.com/category/21/office-school-supplies.html">Office</a>, <a href="//www.aliexpress.com/category/30/security-protection.html">Security</a></span></dt>
			<dd class="sub-cate" data-path="c-computer-content" data-role="first-menu-main"></dd>
		</dl>
		<!--ams-region-end 517--><!--ams-region-start 518-->
		<dl class="cl-item cl-item-electronics" data-role="first-menu" data-spm="105">
			<dt class="cate-name"><span><a href="//www.aliexpress.com/category/44/consumer-electronics.html">Consumer Electronics</a></span></dt>
			<dd class="sub-cate" data-path="c-electronics-content" data-role="first-menu-main"></dd>
		</dl>
		<!--ams-region-end 518--><!--ams-region-start 519-->
		<dl class="cl-item cl-item-jewelry" data-role="first-menu" data-spm="106">
			<dt class="cate-name"><span><a href="//www.aliexpress.com/category/1509/jewelry-accessories.html">Jewelry</a> & <a href="//www.aliexpress.com/category/1511/watches.html?isCates=y">Watches</a></span></dt>
			<dd class="sub-cate" data-path="c-jewelry-content" data-role="first-menu-main"></dd>
		</dl>
		<!--ams-region-end 519--><!--ams-region-start 520-->
		<dl class="cl-item cl-item-garden" data-role="first-menu" data-spm="107">
			<dt class="cate-name"><span><a href="//www.aliexpress.com/category/15/home-garden.html">Home & Garden</a>, <a href="//www.aliexpress.com/category/6/home-appliances.html">Appliance</a></span></dt>
			<dd class="sub-cate" data-path="c-garden-content" data-role="first-menu-main"></dd>
		</dl>
		<!--ams-region-end 520--><!--ams-region-start 521-->
		<dl class="cl-item cl-item-shoes" data-role="first-menu" data-spm="108">
			<dt class="cate-name"><span><a href="//www.aliexpress.com/category/1524/luggage-bags.html">Bags</a> & <a href="//www.aliexpress.com/category/322/shoes.html">Shoes</a></span></dt>
			<dd class="sub-cate" data-path="c-bagsshoes-content" data-role="first-menu-main"></dd>
		</dl>
		<!--ams-region-end 521--><!--ams-region-start 522-->
		<dl class="cl-item cl-item-toys" data-role="first-menu" data-spm="109">
			<dt class="cate-name"><span><a href="//www.aliexpress.com/category/26/toys-hobbies.html">Toys</a>, <a href="//www.aliexpress.com/category/1501/mother-kids.html">Kids & Baby</a></span></dt>
			<dd class="sub-cate" data-path="c-toysbaby-content" data-role="first-menu-main"></dd>
		</dl>
		<!--ams-region-end 522--><!--ams-region-start 523-->
		<dl class="cl-item cl-item-sports" data-role="first-menu" data-spm="110">
			<dt class="cate-name"><span><a href="//www.aliexpress.com/category/18/sports-entertainment.html">Sports & Outdoors</a></span></dt>
			<dd class="sub-cate" data-path="c-sportsoutdoors-content" data-role="first-menu-main"></dd>
		</dl>
		<!--ams-region-end 523--><!--ams-region-start 524-->
		<dl class="cl-item cl-item-beauty" data-role="first-menu" data-spm="111">
			<dt class="cate-name"><span><a href="//www.aliexpress.com/category/66/health-beauty.html">Beauty & Health</a>, <a href="//www.aliexpress.com/category/200002489/hair-extensions-wigs.html">Hair</a></span></dt>
			<dd class="sub-cate" data-path="c-healthbeauty-content" data-role="first-menu-main"></dd>
		</dl>
		<!--ams-region-end 524--><!--ams-region-start 525-->
		<dl class="cl-item cl-item-autoParts" data-role="first-menu" data-spm="112">
			<dt class="cate-name"><span><a href="//www.aliexpress.com/category/34/automobiles-motorcycles.html"> Automobiles & Motorcycles</a></span></dt>
			<dd class="sub-cate" data-path="c-automobiles-content" data-role="first-menu-main"></dd>
		</dl>
		<!--ams-region-end 525--><!--ams-region-start 526-->
		<dl class="cl-item cl-item-homeImprovement" data-role="first-menu" data-spm="113">
			<dt class="cate-name"><span><a href="//www.aliexpress.com/category/13/home-improvement.html">Home Improvement</a>, <a href="//www.aliexpress.com/category/1420/tools.html">Tools</a></span></dt>
			<dd class="sub-cate" data-path="c-homeimprovement-content" data-role="first-menu-main"></dd>
		</dl>
		<!--ams-region-end 526--></div>
</div>
 <!--ams-region-end 500-->
                        </div>
        <!-- category end -->
        <!-- banner start -->
        <div class="advertise-main util-clearfix"/>
        <div class="ui-banner-slider col-md-40 col-lg-40 key-visual-main" id="key-visual-main" style="width: 720px"
             data-spm="3">
                    <div class="ui-banner-slider-wrap">
                <div class="ui-banner-slider-container" style="width: 720px">
                    <ul class="ui-banner-slider-slider" data-role="slider">
                                                                                    <li style="width: 720px">
                                    <a href="https://campaign.aliexpress.com/wow/gf/upr-daily?wh_pid=February_phone_brand_week&wh_weex=true&preDownLoad=true&preInitInstance=rax" target="_blank">
                                        <img src="//ae01.alicdn.com/kf/Hf881edee3a7a46449067078e866837ccE.png" data-loaded="true" alt="" width="720" height="288"/>
                                    </a>
                                </li>

                                                                                    <li style="width: 720px">
                                    <a href="https://campaign.aliexpress.com/wow/gf/upr-daily?wh_pid=February_consumer_2020&wh_weex=true&preDownLoad=true&preInitInstance=rax" target="_blank">
                                        <img class="banner-slider-img" src="//ae01.alicdn.com/kf/HTB1Awaxezgy_uJjSZKz762_jXXau.png" data-slider="//ae01.alicdn.com/kf/He1b74f5597ec40f689b92508150e1102e.png" data-loaded="true" alt="" width="720" height="288"/>
                                    </a>
                                </li>

                                                                                    <li style="width: 720px">
                                    <a href="https://campaign.aliexpress.com/wow/gf/upr-daily?wh_pid=more_than_time_watch&wh_weex=true&preDownLoad=true&preInitInstance=rax&_immersiveMode=true&wx_navbar_hidden=true&wx_navbar_transparent=true&wx_statusbar_hidden=true&ignoreNavigationBar=true" target="_blank">
                                        <img class="banner-slider-img" src="//ae01.alicdn.com/kf/HTB1Awaxezgy_uJjSZKz762_jXXau.png" data-slider="//ae01.alicdn.com/kf/H672a40826fba45328742676fc47f238fc.gif" data-loaded="true" alt="" width="720" height="288"/>
                                    </a>
                                </li>

                                                                                    <li style="width: 720px">
                                    <a href="https://campaign.aliexpress.com/wow/gf/upr-daily?wh_pid=tools_improvement_spring&wh_weex=true&preDownLoad=true&preInitInstance=rax" target="_blank">
                                        <img class="banner-slider-img" src="//ae01.alicdn.com/kf/HTB1Awaxezgy_uJjSZKz762_jXXau.png" data-slider="//ae01.alicdn.com/kf/H14bfb226a9c94c41bfd05da6e3ac05ceT.png" data-loaded="true" alt="" width="720" height="288"/>
                                    </a>
                                </li>

                                                                                    <li style="width: 720px">
                                    <a href="https://campaign.aliexpress.com/wow/gf/upr-daily?wh_pid=Home_Design_Week_20200210&wh_weex=true&preDownLoad=true&preInitInstance=rax&_immersiveMode=true&wx_navbar_hidden=true&wx_navbar_transparent=true&wx_statusbar_hidden=true&ignoreNavigationBar=true" target="_blank">
                                        <img class="banner-slider-img" src="//ae01.alicdn.com/kf/HTB1Awaxezgy_uJjSZKz762_jXXau.png" data-slider="//ae01.alicdn.com/kf/Hf46448aa16fd4c3d90215ea4ebd2009at.png" data-loaded="true" alt="" width="720" height="288"/>
                                    </a>
                                </li>

                                                                                    <li style="width: 720px">
                                    <a href="https://campaign.aliexpress.com/wow/gf/upr-daily?wh_pid=Beauty_Health_Brands&wh_weex=true&preDownLoad=true&preInitInstance=rax&_immersiveMode=true&wx_navbar_hidden=true&wx_navbar_transparent=true&wx_statusbar_hidden=true&ignoreNavigationBar=true" target="_blank">
                                        <img class="banner-slider-img" src="//ae01.alicdn.com/kf/HTB1Awaxezgy_uJjSZKz762_jXXau.png" data-slider="//ae01.alicdn.com/kf/H78fd2eb8394c4688be16168031623a98a.png" data-loaded="true" alt="" width="720" height="288"/>
                                    </a>
                                </li>

                                            </ul>
                    <a class="ui-banner-slider-prev" data-role="prev">Previous</a>
                    <a class="ui-banner-slider-next" data-role="next">Next</a>
                </div>
            </div>

            <!--标签会场-->
            <div id="home-label-venue-area" class="brand-banner util-clearfix" data-spm="4" data-scm="1007.20779.159297.0"
                 data-pvid="e1427447-8ba8-4ed9-bdf6-a64e6ba39dfd">
                                                    <div class="brand-banner-close">
                        <a href="https://sale.aliexpress.com/Labelvenue.htm?scm=1007.20779.159297.0&pvid=e1427447-8ba8-4ed9-bdf6-a64e6ba39dfd&tagId=27002&itemId=32956958681" target="_blank" data-role="item-box" data-productid="32956958681"
                           data-tagId="27002" data-algoInfo="27002_0_0_cookie_id:a7552d58b19e4effaa42b4ae16b86fd7_">
                                                            <div class="title" ID="label-title-each">
                                    <span class="purple">●</span>
                                    Water Sport
                                </div>
                                                        <div class="img">
                                <div class="price">US $5.63</div>
                                <img src="//ae01.alicdn.com/kf/HTB1Awaxezgy_uJjSZKz762_jXXau.png" data-label-img="//ae01.alicdn.com/kf/HTB17sdOXZfrK1RkSmLyq6xGApXaf.jpg_200x200.jpg"/>
                            </div>
                        </a>
                    </div>
                                    <div class="brand-banner-close">
                        <a href="https://sale.aliexpress.com/Labelvenue.htm?scm=1007.20779.159297.0&pvid=e1427447-8ba8-4ed9-bdf6-a64e6ba39dfd&tagId=12101410000&itemId=4000021440508" target="_blank" data-role="item-box" data-productid="4000021440508"
                           data-tagId="12101410000" data-algoInfo="12101410000_0_1_cookie_id:a7552d58b19e4effaa42b4ae16b86fd7_">
                                                            <div class="title" ID="label-title-each">
                                    <span class="yellow">●</span>
                                    Climbing
                                </div>
                                                        <div class="img">
                                <div class="price">US $9.03</div>
                                <img src="//ae01.alicdn.com/kf/HTB1Awaxezgy_uJjSZKz762_jXXau.png" data-label-img="//ae01.alicdn.com/kf/HTB1KPMVaUY1gK0jSZFCq6AwqXXaM.jpg_200x200.jpg"/>
                            </div>
                        </a>
                    </div>
                                    <div class="brand-banner-close">
                        <a href="https://sale.aliexpress.com/Labelvenue.htm?scm=1007.20779.159297.0&pvid=e1427447-8ba8-4ed9-bdf6-a64e6ba39dfd&tagId=21004&itemId=4000163176491" target="_blank" data-role="item-box" data-productid="4000163176491"
                           data-tagId="21004" data-algoInfo="21004_0_2_cookie_id:a7552d58b19e4effaa42b4ae16b86fd7_">
                                                            <div class="title" ID="label-title-each">
                                    <span class="pink">●</span>
                                    Career Hero
                                </div>
                                                        <div class="img">
                                <div class="price">US $45.59</div>
                                <img src="//ae01.alicdn.com/kf/HTB1Awaxezgy_uJjSZKz762_jXXau.png" data-label-img="//ae01.alicdn.com/kf/Hdf24945975f947ae946295dd4b689093L.jpg_200x200.jpg"/>
                            </div>
                        </a>
                    </div>
                                    <div class="brand-banner-close">
                        <a href="https://sale.aliexpress.com/Labelvenue.htm?scm=1007.20779.159297.0&pvid=e1427447-8ba8-4ed9-bdf6-a64e6ba39dfd&tagId=15121000000&itemId=32962483578" target="_blank" data-role="item-box" data-productid="32962483578"
                           data-tagId="15121000000" data-algoInfo="15121000000_0_3_cookie_id:a7552d58b19e4effaa42b4ae16b86fd7_">
                                                            <div class="title" ID="label-title-each">
                                    <span class="orange">●</span>
                                    Fishing
                                </div>
                                                        <div class="img">
                                <div class="price">US $8.39</div>
                                <img src="//ae01.alicdn.com/kf/HTB1Awaxezgy_uJjSZKz762_jXXau.png" data-label-img="//ae01.alicdn.com/kf/HTB1Ay_NeRGw3KVjSZFwq6zQ2FXa2.jpg_200x200.jpg"/>
                            </div>
                        </a>
                    </div>
                                    <div class="brand-banner-close">
                        <a href="https://sale.aliexpress.com/Labelvenue.htm?scm=1007.20779.159297.0&pvid=e1427447-8ba8-4ed9-bdf6-a64e6ba39dfd&tagId=26002&itemId=32816909139" target="_blank" data-role="item-box" data-productid="32816909139"
                           data-tagId="26002" data-algoInfo="26002_0_4_cookie_id:a7552d58b19e4effaa42b4ae16b86fd7_">
                                                            <div class="title" ID="label-title-each">
                                    <span class="green">●</span>
                                    Love Home
                                </div>
                                                        <div class="img">
                                <div class="price">US $14.00</div>
                                <img src="//ae01.alicdn.com/kf/HTB1Awaxezgy_uJjSZKz762_jXXau.png" data-label-img="//ae01.alicdn.com/kf/HTB1vY0Bqh1YBuNjy1zcq6zNcXXaJ.jpg_200x200.jpg"/>
                            </div>
                        </a>
                    </div>
                                    <div class="brand-banner-close">
                        <a href="https://sale.aliexpress.com/Labelvenue.htm?scm=1007.20779.159297.0&pvid=e1427447-8ba8-4ed9-bdf6-a64e6ba39dfd&tagId=15141200000&itemId=32969508231" target="_blank" data-role="item-box" data-productid="32969508231"
                           data-tagId="15141200000" data-algoInfo="15141200000_0_5_cookie_id:a7552d58b19e4effaa42b4ae16b86fd7_">
                                                            <div class="title" ID="label-title-each">
                                    <span class="blue">●</span>
                                    Hunting
                                </div>
                                                        <div class="img">
                                <div class="price">US $79.99</div>
                                <img src="//ae01.alicdn.com/kf/HTB1Awaxezgy_uJjSZKz762_jXXau.png" data-label-img="//ae01.alicdn.com/kf/Ha570161704134ccebd67d07c6781db1ej.jpg_200x200.jpg"/>
                            </div>
                        </a>
                    </div>
                            </div>

        </div>
            <div class="right-banner" data-spm="5">
            <a href="https://sale.aliexpress.com/newuser_zone.htm" target="_blank">
                <img class="coupon-banner" src="//ae01.alicdn.com/kf/HTB1Awaxezgy_uJjSZKz762_jXXau.png" data-right-banner="//ae01.alicdn.com/kf/H64b99d97b58c4f61982cf76eef94d2a2K.png" alt="" width="240" height="auto"/>
            </a>
        </div>
    </div>
    <!-- banner end -->
</div>
</div>
<footer class="footer-section">
    <div class="container">
        <div class="row">
            <div class="col-lg-3">
                <div class="footer-left">
                    <div class="footer-logo">
                        <a href="#"><img src="img/footer-logo.png" alt=""></a>
                    </div>
                    <ul>
                        <li>Address:Taborah - Scorpion, Greater Accra.
                            House Of Kings Building</li>
                        <li>Phone:  +233 277500001</li>
                        <li>Email:  info@tuatuagye.com</li>
                    </ul>
                    <div class="footer-social">
                        <a href="#"><i class="fa fa-facebook"></i></a>
                        <a href="#"><i class="fa fa-instagram"></i></a>
                        <a href="#"><i class="fa fa-twitter"></i></a>
                        <a href="#"><i class="fa fa-pinterest"></i></a>
                    </div>
                </div>
            </div>
            <div class="col-lg-2 offset-lg-1">
                <div class="footer-widget">
                    <h5>Information</h5>
                    <ul>
                        <li><a href="#">About Us</a></li>
                        <li><a href="#">Checkout</a></li>
                        <li><a href="#">Contact</a></li>
                        <li><a href="#">Serivius</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-2">
                <div class="footer-widget">
                    <h5>My Account</h5>
                    <ul>
                        <li><a href="#">My Account</a></li>
                        <li><a href="#">Contact</a></li>
                        <li><a href="#">Shopping Cart</a></li>
                        <li><a href="#">Shop</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="newslatter-item">
                    <h5>Join Our Newsletter Now</h5>
                    <p>Get E-mail updates about our latest shop and special offers.</p>
                    <form action="#" class="subscribe-form">
                        <input type="text" placeholder="Enter Your Mail">
                        <button type="button">Subscribe</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="copyright-reserved">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="copyright-text">
                        <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                    </div>
                    <div class="payment-pic">
                        <img src="img/payment-method.png" alt="">
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<style>
  div.black {
background-color: black;

  }

</style>


{!! '<h2>home page!</h2>' !!}

@endsection





















    <!-- Header Section Begin -->
    <header class="header-section">
        <div class="header-top">
            <div class="container">
                <div class="ht-left">
                    <div class="mail-service">
                        <i class=" fa fa-envelope"></i>
                        info@tuatuagye.com
                    </div>
                    <div class="phone-service">
                        <i class=" fa fa-phone"></i>
                        +233 277500001
                    </div>
                </div>
                <div class="ht-right">
                    <a href="#" class="login-panel"><i class="fa fa-user"></i>Login</a>
                    <div class="lan-selector">
                        <select class="language_drop" name="countries" id="countries" style="width:300px;">
                            <option value='yt' data-image="img/flag-1.jpg" data-imagecss="flag yt"
                                data-title="English">English</option>
                            <option value='yu' data-image="img/flag-2.jpg" data-imagecss="flag yu"
                                data-title="Bangladesh">German </option>
                        </select>
                    </div>
                    <div class="top-social">
                        <a href="#"><i class="ti-facebook"></i></a>
                        <a href="#"><i class="ti-twitter-alt"></i></a>
                        <a href="#"><i class="ti-linkedin"></i></a>
                        <a href="#"><i class="ti-pinterest"></i></a>
                    </div>
                </div>
            </div>
        </div>


        <div class="container">
            <div class="inner-header">
                <div class="row">
                    <div class="col-lg-2 col-md-2">
                        <div class="logo1" style="
                            max-height:100px;
                           max-width:100px;


                           left: 0%;
                           ">
                            <a href="#">
                                <img src="img/logo1.png" alt="">
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-7 col-md-7">
                        <div class="advanced-search">
                            <button type="button" class="category-btn">All Categories</button>
                            <div class="input-group">
                                <input type="text" placeholder="What do you need?">
                                <button type="button" style="background-color: rgb(49, 143, 143)"><i class="ti-search" ></i></button>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3 text-right col-md-3">
                        <ul class="nav-right">
                            <li class="heart-icon">
                                <a href="#">
                                    <i class="icon_heart_alt"></i>
                                    <span>1</span>
                                </a>
                            </li>
                            <li class="cart-icon">
                                <a href="#">
                                    <i class="icon_bag_alt"></i>
                                    <span>3</span>
                                </a>
                                <div class="cart-hover">
                                    <div class="select-items">
                                        <table>
                                            <tbody>
                                                <tr>
                                                    <td class="si-pic"><img src="img/select-product-1.jpg" alt=""></td>
                                                    <td class="si-text">
                                                        <div class="product-selected">
                                                            <p>$60.00 x 1</p>
                                                            <h6>Kabino Bedside Table</h6>
                                                        </div>
                                                    </td>
                                                    <td class="si-close">
                                                        <i class="ti-close"></i>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="si-pic"><img src="img/select-product-2.jpg" alt=""></td>
                                                    <td class="si-text">
                                                        <div class="product-selected">
                                                            <p>$60.00 x 1</p>
                                                            <h6>Kabino Bedside Table</h6>
                                                        </div>
                                                    </td>
                                                    <td class="si-close">
                                                        <i class="ti-close"></i>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                    <div class="select-total">
                                        <span>total:</span>
                                        <h5>$120.00</h5>
                                    </div>
                                    <div class="select-button">
                                        <a href="#" class="primary-btn view-card">VIEW CARD</a>
                                        <a href="#" class="primary-btn checkout-btn">CHECK OUT</a>
                                    </div>
                                </div>
                            </li>
                            <li class="cart-price">$150.00</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

<div class="black">
        <div class="container">
            <div class="inner-header">

                <div class="container my-4">


                    <hr class="my-4">

                    <!--Carousel Wrapper-->
                    <div id="carousel-thumb" class="carousel slide carousel-fade carousel-thumbnails" data-ride="carousel">
                      <!--Slides-->
                      <div class="carousel-inner" role="listbox">
                        <div class="carousel-item active">
                          <img class="d-block w-100" src="https://mdbootstrap.com/img/Photos/Slides/img%20(88).jpg" alt="First slide">
                        </div>
                        <div class="carousel-item">
                          <img class="d-block w-100" src="https://mdbootstrap.com/img/Photos/Slides/img%20(121).jpg" alt="Second slide">
                        </div>
                        <div class="carousel-item">
                          <img class="d-block w-100" src="https://mdbootstrap.com/img/Photos/Slides/img%20(31).jpg" alt="Third slide">
                        </div>
                      </div>
                      <!--/.Slides-->
                      <!--Controls-->
                      <a class="carousel-control-prev" href="#carousel-thumb" role="button" data-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="sr-only">Previous</span>
                      </a>
                      <a class="carousel-control-next" href="#carousel-thumb" role="button" data-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="sr-only">Next</span>
                      </a>
                      <!--/.Controls-->
                      <ol class="carousel-indicators">
                        <li data-target="#carousel-thumb" data-slide-to="0" class="active"> <img class="d-block w-100" src="https://mdbootstrap.com/img/Photos/Others/Carousel-thumbs/img%20(88).jpg"
                            class="img-fluid"></li>
                        <li data-target="#carousel-thumb" data-slide-to="1"><img class="d-block w-100" src="https://mdbootstrap.com/img/Photos/Others/Carousel-thumbs/img%20(121).jpg"
                            class="img-fluid"></li>
                        <li data-target="#carousel-thumb" data-slide-to="2"><img class="d-block w-100" src="https://mdbootstrap.com/img/Photos/Others/Carousel-thumbs/img%20(31).jpg"
                            class="img-fluid"></li>
                      </ol>
                    </div>
                    <!--/.Carousel Wrapper-->

                  </div>
            </div>

            </div>
        </div>
        <div class="nav-item">
            <div class="container">
                <div class="nav-depart">
                    <div class="depart-btn">
                        <i class="ti-menu"></i>
                        <span>Category</span>
                        <ul class="depart-hover">
                            <li class="active"><a href="#">Phones</a></li>
                            <li><a href="#">Laptops</a></li>
                            <li><a href="#">TV</a></li>
                            <li><a href="#">Speaker</a></li>
                            <li><a href="#">Kitchen Appliance</a></li>
                            <li><a href="#">Accessories</a></li>
                            <li><a href="#">Luxury Brands</a></li>

                        </ul>
                    </div>
                </div>

    <!-- Header End -->

  <!--/ Carousel Star /-->


            </div>
        </div>

        <div class="container">

  <h1 class="font-weight-light text-center text-lg-left mt-4 mb-0">shop</h1>

  <hr class="mt-2 mb-5">

  <div class="row text-center text-lg-left">

    <div class="col-lg-3 col-md-4 col-6">
      <a href="#" class="d-block mb-4 h-100">
            <img class="img-fluid img-thumbnail" src="https://source.unsplash.com/pWkk7iiCoDM/400x300" alt="">
          </a>
    </div>
    <div class="col-lg-3 col-md-4 col-6">
      <a href="#" class="d-block mb-4 h-100">
            <img class="img-fluid img-thumbnail" src="https://source.unsplash.com/aob0ukAYfuI/400x300" alt="">
          </a>
    </div>
    <div class="col-lg-3 col-md-4 col-6">
      <a href="#" class="d-block mb-4 h-100">
            <img class="img-fluid img-thumbnail" src="https://source.unsplash.com/EUfxH-pze7s/400x300" alt="">
          </a>
    </div>
    <div class="col-lg-3 col-md-4 col-6">
      <a href="#" class="d-block mb-4 h-100">
            <img class="img-fluid img-thumbnail" src="https://source.unsplash.com/M185_qYH8vg/400x300" alt="">
          </a>
    </div>

  </div>

</div>
<!-- /.container -->

<div class="_new-top-container-bg"></div>


<div class="_new-top-container-bg-bar"></div>
<div id="home-firstscreen" class="home-firstscreen _new-home-firstscreen container">
    <div class="home-firstscreen-main _new-home-firstscreen-main">
        <div class="channel-entrance" data-spm="9">
                                <!--ams-region-start 1202-->
<style type="text/css">.new-user-container .coupon-text {
        font-size: 13px;
    }
</style>
<div class="channel-entrance" data-spm="01002" data-test="noah"><a href="//sale.aliexpress.com/supervaluedeal.htm">SUPER VALUE DEALS <span class="marking"> </span></a><a href="//campaign.aliexpress.com/wow/gf/upr-daily?wh_pid=big_discount_page&wh_weex=true&preDownLoad=true&preInitInstance=rax&_immersiveMode=true&wx_navbar_hidden=true&wx_navbar_transparent=true&wx_statusbar_hidden=true&ignoreNavigationBar=true">Big Discounts </a><a href="//sale.aliexpress.com/affiliate_Select_Coupons.htm">Select Coupons </a><a href="//sale.aliexpress.com/category_homegarden_affliate.htm">Home </a><a href="//sale.aliexpress.com/category_tech_affliate.htm">Tech </a><a href="//sale.aliexpress.com/aff_beauty.htm">Beauty </a></div>
 <!--ams-region-end 1202-->
            </div>

        <!-- category start -->
        <div class="categories">

                                        <!--ams-region-start 500-->
<div class="categories-main new-categories-main categories-main-home" data-role="category-content" data-spm="22">
	<div class="categories-content-title" data-role="exclude"><span>CATEGORIES</span><a href="//www.aliexpress.com/all-wholesale-products.html">See All &gt;</a></div>

	<div class="categories-list-box"><!--ams-region-start 514-->
		<dl class="cl-item cl-item-women" data-role="first-menu" data-spm="101">
			<dt class="cate-name"><span><a href="//www.aliexpress.com/category/100003109/women-clothing-accessories.html"> Women’s Clothing</a></span></dt>
			<dd class="sub-cate" data-path="c-women-content" data-role="first-menu-main"></dd>
		</dl>
		<!--ams-region-end 514--><!--ams-region-start 515-->
		<dl class="cl-item cl-item-men" data-role="first-menu" data-spm="102">
			<dt class="cate-name"><span><a href="//www.aliexpress.com/category/100003070/men-clothing-accessories.html">Men’s Clothing</a></span></dt>
			<dd class="sub-cate" data-path="c-men-content" data-role="first-menu-main"></dd>
		</dl>
		<!--ams-region-end 515--><!--ams-region-start 516-->
		<dl class="cl-item cl-item-phones" data-role="first-menu" data-spm="103">
			<dt class="cate-name"><span><a href="//www.aliexpress.com/category/509/cellphones-telecommunications.html">Phones & Accessories</a></span></dt>
			<dd class="sub-cate" data-path="c-phones-content" data-role="first-menu-main"></dd>
		</dl>
		<!--ams-region-end 516--><!--ams-region-start 517-->
		<dl class="cl-item cl-item-computer" data-role="first-menu" data-spm="104">
			<dt class="cate-name"><span><a href="//www.aliexpress.com/category/7/computer-office.html">Computer</a>, <a href="//www.aliexpress.com/category/21/office-school-supplies.html">Office</a>, <a href="//www.aliexpress.com/category/30/security-protection.html">Security</a></span></dt>
			<dd class="sub-cate" data-path="c-computer-content" data-role="first-menu-main"></dd>
		</dl>
		<!--ams-region-end 517--><!--ams-region-start 518-->
		<dl class="cl-item cl-item-electronics" data-role="first-menu" data-spm="105">
			<dt class="cate-name"><span><a href="//www.aliexpress.com/category/44/consumer-electronics.html">Consumer Electronics</a></span></dt>
			<dd class="sub-cate" data-path="c-electronics-content" data-role="first-menu-main"></dd>
		</dl>
		<!--ams-region-end 518--><!--ams-region-start 519-->
		<dl class="cl-item cl-item-jewelry" data-role="first-menu" data-spm="106">
			<dt class="cate-name"><span><a href="//www.aliexpress.com/category/1509/jewelry-accessories.html">Jewelry</a> & <a href="//www.aliexpress.com/category/1511/watches.html?isCates=y">Watches</a></span></dt>
			<dd class="sub-cate" data-path="c-jewelry-content" data-role="first-menu-main"></dd>
		</dl>
		<!--ams-region-end 519--><!--ams-region-start 520-->
		<dl class="cl-item cl-item-garden" data-role="first-menu" data-spm="107">
			<dt class="cate-name"><span><a href="//www.aliexpress.com/category/15/home-garden.html">Home & Garden</a>, <a href="//www.aliexpress.com/category/6/home-appliances.html">Appliance</a></span></dt>
			<dd class="sub-cate" data-path="c-garden-content" data-role="first-menu-main"></dd>
		</dl>
		<!--ams-region-end 520--><!--ams-region-start 521-->
		<dl class="cl-item cl-item-shoes" data-role="first-menu" data-spm="108">
			<dt class="cate-name"><span><a href="//www.aliexpress.com/category/1524/luggage-bags.html">Bags</a> & <a href="//www.aliexpress.com/category/322/shoes.html">Shoes</a></span></dt>
			<dd class="sub-cate" data-path="c-bagsshoes-content" data-role="first-menu-main"></dd>
		</dl>
		<!--ams-region-end 521--><!--ams-region-start 522-->
		<dl class="cl-item cl-item-toys" data-role="first-menu" data-spm="109">
			<dt class="cate-name"><span><a href="//www.aliexpress.com/category/26/toys-hobbies.html">Toys</a>, <a href="//www.aliexpress.com/category/1501/mother-kids.html">Kids & Baby</a></span></dt>
			<dd class="sub-cate" data-path="c-toysbaby-content" data-role="first-menu-main"></dd>
		</dl>
		<!--ams-region-end 522--><!--ams-region-start 523-->
		<dl class="cl-item cl-item-sports" data-role="first-menu" data-spm="110">
			<dt class="cate-name"><span><a href="//www.aliexpress.com/category/18/sports-entertainment.html">Sports & Outdoors</a></span></dt>
			<dd class="sub-cate" data-path="c-sportsoutdoors-content" data-role="first-menu-main"></dd>
		</dl>
		<!--ams-region-end 523--><!--ams-region-start 524-->
		<dl class="cl-item cl-item-beauty" data-role="first-menu" data-spm="111">
			<dt class="cate-name"><span><a href="//www.aliexpress.com/category/66/health-beauty.html">Beauty & Health</a>, <a href="//www.aliexpress.com/category/200002489/hair-extensions-wigs.html">Hair</a></span></dt>
			<dd class="sub-cate" data-path="c-healthbeauty-content" data-role="first-menu-main"></dd>
		</dl>
		<!--ams-region-end 524--><!--ams-region-start 525-->
		<dl class="cl-item cl-item-autoParts" data-role="first-menu" data-spm="112">
			<dt class="cate-name"><span><a href="//www.aliexpress.com/category/34/automobiles-motorcycles.html"> Automobiles & Motorcycles</a></span></dt>
			<dd class="sub-cate" data-path="c-automobiles-content" data-role="first-menu-main"></dd>
		</dl>
		<!--ams-region-end 525--><!--ams-region-start 526-->
		<dl class="cl-item cl-item-homeImprovement" data-role="first-menu" data-spm="113">
			<dt class="cate-name"><span><a href="//www.aliexpress.com/category/13/home-improvement.html">Home Improvement</a>, <a href="//www.aliexpress.com/category/1420/tools.html">Tools</a></span></dt>
			<dd class="sub-cate" data-path="c-homeimprovement-content" data-role="first-menu-main"></dd>
		</dl>
		<!--ams-region-end 526--></div>
</div>
 <!--ams-region-end 500-->
                        </div>
        <!-- category end -->
        <!-- banner start -->
        <div class="advertise-main util-clearfix"/>
        <div class="ui-banner-slider col-md-40 col-lg-40 key-visual-main" id="key-visual-main" style="width: 720px"
             data-spm="3">
                    <div class="ui-banner-slider-wrap">
                <div class="ui-banner-slider-container" style="width: 720px">
                    <ul class="ui-banner-slider-slider" data-role="slider">
                                                                                    <li style="width: 720px">
                                    <a href="https://campaign.aliexpress.com/wow/gf/upr-daily?wh_pid=February_phone_brand_week&wh_weex=true&preDownLoad=true&preInitInstance=rax" target="_blank">
                                        <img src="//ae01.alicdn.com/kf/Hf881edee3a7a46449067078e866837ccE.png" data-loaded="true" alt="" width="720" height="288"/>
                                    </a>
                                </li>

                                                                                    <li style="width: 720px">
                                    <a href="https://campaign.aliexpress.com/wow/gf/upr-daily?wh_pid=February_consumer_2020&wh_weex=true&preDownLoad=true&preInitInstance=rax" target="_blank">
                                        <img class="banner-slider-img" src="//ae01.alicdn.com/kf/HTB1Awaxezgy_uJjSZKz762_jXXau.png" data-slider="//ae01.alicdn.com/kf/He1b74f5597ec40f689b92508150e1102e.png" data-loaded="true" alt="" width="720" height="288"/>
                                    </a>
                                </li>

                                                                                    <li style="width: 720px">
                                    <a href="https://campaign.aliexpress.com/wow/gf/upr-daily?wh_pid=more_than_time_watch&wh_weex=true&preDownLoad=true&preInitInstance=rax&_immersiveMode=true&wx_navbar_hidden=true&wx_navbar_transparent=true&wx_statusbar_hidden=true&ignoreNavigationBar=true" target="_blank">
                                        <img class="banner-slider-img" src="//ae01.alicdn.com/kf/HTB1Awaxezgy_uJjSZKz762_jXXau.png" data-slider="//ae01.alicdn.com/kf/H672a40826fba45328742676fc47f238fc.gif" data-loaded="true" alt="" width="720" height="288"/>
                                    </a>
                                </li>

                                                                                    <li style="width: 720px">
                                    <a href="https://campaign.aliexpress.com/wow/gf/upr-daily?wh_pid=tools_improvement_spring&wh_weex=true&preDownLoad=true&preInitInstance=rax" target="_blank">
                                        <img class="banner-slider-img" src="//ae01.alicdn.com/kf/HTB1Awaxezgy_uJjSZKz762_jXXau.png" data-slider="//ae01.alicdn.com/kf/H14bfb226a9c94c41bfd05da6e3ac05ceT.png" data-loaded="true" alt="" width="720" height="288"/>
                                    </a>
                                </li>

                                                                                    <li style="width: 720px">
                                    <a href="https://campaign.aliexpress.com/wow/gf/upr-daily?wh_pid=Home_Design_Week_20200210&wh_weex=true&preDownLoad=true&preInitInstance=rax&_immersiveMode=true&wx_navbar_hidden=true&wx_navbar_transparent=true&wx_statusbar_hidden=true&ignoreNavigationBar=true" target="_blank">
                                        <img class="banner-slider-img" src="//ae01.alicdn.com/kf/HTB1Awaxezgy_uJjSZKz762_jXXau.png" data-slider="//ae01.alicdn.com/kf/Hf46448aa16fd4c3d90215ea4ebd2009at.png" data-loaded="true" alt="" width="720" height="288"/>
                                    </a>
                                </li>

                                                                                    <li style="width: 720px">
                                    <a href="https://campaign.aliexpress.com/wow/gf/upr-daily?wh_pid=Beauty_Health_Brands&wh_weex=true&preDownLoad=true&preInitInstance=rax&_immersiveMode=true&wx_navbar_hidden=true&wx_navbar_transparent=true&wx_statusbar_hidden=true&ignoreNavigationBar=true" target="_blank">
                                        <img class="banner-slider-img" src="//ae01.alicdn.com/kf/HTB1Awaxezgy_uJjSZKz762_jXXau.png" data-slider="//ae01.alicdn.com/kf/H78fd2eb8394c4688be16168031623a98a.png" data-loaded="true" alt="" width="720" height="288"/>
                                    </a>
                                </li>

                                            </ul>
                    <a class="ui-banner-slider-prev" data-role="prev">Previous</a>
                    <a class="ui-banner-slider-next" data-role="next">Next</a>
                </div>
            </div>

            <!--标签会场-->
            <div id="home-label-venue-area" class="brand-banner util-clearfix" data-spm="4" data-scm="1007.20779.159297.0"
                 data-pvid="e1427447-8ba8-4ed9-bdf6-a64e6ba39dfd">
                                                    <div class="brand-banner-close">
                        <a href="https://sale.aliexpress.com/Labelvenue.htm?scm=1007.20779.159297.0&pvid=e1427447-8ba8-4ed9-bdf6-a64e6ba39dfd&tagId=27002&itemId=32956958681" target="_blank" data-role="item-box" data-productid="32956958681"
                           data-tagId="27002" data-algoInfo="27002_0_0_cookie_id:a7552d58b19e4effaa42b4ae16b86fd7_">
                                                            <div class="title" ID="label-title-each">
                                    <span class="purple">●</span>
                                    Water Sport
                                </div>
                                                        <div class="img">
                                <div class="price">US $5.63</div>
                                <img src="//ae01.alicdn.com/kf/HTB1Awaxezgy_uJjSZKz762_jXXau.png" data-label-img="//ae01.alicdn.com/kf/HTB17sdOXZfrK1RkSmLyq6xGApXaf.jpg_200x200.jpg"/>
                            </div>
                        </a>
                    </div>
                                    <div class="brand-banner-close">
                        <a href="https://sale.aliexpress.com/Labelvenue.htm?scm=1007.20779.159297.0&pvid=e1427447-8ba8-4ed9-bdf6-a64e6ba39dfd&tagId=12101410000&itemId=4000021440508" target="_blank" data-role="item-box" data-productid="4000021440508"
                           data-tagId="12101410000" data-algoInfo="12101410000_0_1_cookie_id:a7552d58b19e4effaa42b4ae16b86fd7_">
                                                            <div class="title" ID="label-title-each">
                                    <span class="yellow">●</span>
                                    Climbing
                                </div>
                                                        <div class="img">
                                <div class="price">US $9.03</div>
                                <img src="//ae01.alicdn.com/kf/HTB1Awaxezgy_uJjSZKz762_jXXau.png" data-label-img="//ae01.alicdn.com/kf/HTB1KPMVaUY1gK0jSZFCq6AwqXXaM.jpg_200x200.jpg"/>
                            </div>
                        </a>
                    </div>
                                    <div class="brand-banner-close">
                        <a href="https://sale.aliexpress.com/Labelvenue.htm?scm=1007.20779.159297.0&pvid=e1427447-8ba8-4ed9-bdf6-a64e6ba39dfd&tagId=21004&itemId=4000163176491" target="_blank" data-role="item-box" data-productid="4000163176491"
                           data-tagId="21004" data-algoInfo="21004_0_2_cookie_id:a7552d58b19e4effaa42b4ae16b86fd7_">
                                                            <div class="title" ID="label-title-each">
                                    <span class="pink">●</span>
                                    Career Hero
                                </div>
                                                        <div class="img">
                                <div class="price">US $45.59</div>
                                <img src="//ae01.alicdn.com/kf/HTB1Awaxezgy_uJjSZKz762_jXXau.png" data-label-img="//ae01.alicdn.com/kf/Hdf24945975f947ae946295dd4b689093L.jpg_200x200.jpg"/>
                            </div>
                        </a>
                    </div>
                                    <div class="brand-banner-close">
                        <a href="https://sale.aliexpress.com/Labelvenue.htm?scm=1007.20779.159297.0&pvid=e1427447-8ba8-4ed9-bdf6-a64e6ba39dfd&tagId=15121000000&itemId=32962483578" target="_blank" data-role="item-box" data-productid="32962483578"
                           data-tagId="15121000000" data-algoInfo="15121000000_0_3_cookie_id:a7552d58b19e4effaa42b4ae16b86fd7_">
                                                            <div class="title" ID="label-title-each">
                                    <span class="orange">●</span>
                                    Fishing
                                </div>
                                                        <div class="img">
                                <div class="price">US $8.39</div>
                                <img src="//ae01.alicdn.com/kf/HTB1Awaxezgy_uJjSZKz762_jXXau.png" data-label-img="//ae01.alicdn.com/kf/HTB1Ay_NeRGw3KVjSZFwq6zQ2FXa2.jpg_200x200.jpg"/>
                            </div>
                        </a>
                    </div>
                                    <div class="brand-banner-close">
                        <a href="https://sale.aliexpress.com/Labelvenue.htm?scm=1007.20779.159297.0&pvid=e1427447-8ba8-4ed9-bdf6-a64e6ba39dfd&tagId=26002&itemId=32816909139" target="_blank" data-role="item-box" data-productid="32816909139"
                           data-tagId="26002" data-algoInfo="26002_0_4_cookie_id:a7552d58b19e4effaa42b4ae16b86fd7_">
                                                            <div class="title" ID="label-title-each">
                                    <span class="green">●</span>
                                    Love Home
                                </div>
                                                        <div class="img">
                                <div class="price">US $14.00</div>
                                <img src="//ae01.alicdn.com/kf/HTB1Awaxezgy_uJjSZKz762_jXXau.png" data-label-img="//ae01.alicdn.com/kf/HTB1vY0Bqh1YBuNjy1zcq6zNcXXaJ.jpg_200x200.jpg"/>
                            </div>
                        </a>
                    </div>
                                    <div class="brand-banner-close">
                        <a href="https://sale.aliexpress.com/Labelvenue.htm?scm=1007.20779.159297.0&pvid=e1427447-8ba8-4ed9-bdf6-a64e6ba39dfd&tagId=15141200000&itemId=32969508231" target="_blank" data-role="item-box" data-productid="32969508231"
                           data-tagId="15141200000" data-algoInfo="15141200000_0_5_cookie_id:a7552d58b19e4effaa42b4ae16b86fd7_">
                                                            <div class="title" ID="label-title-each">
                                    <span class="blue">●</span>
                                    Hunting
                                </div>
                                                        <div class="img">
                                <div class="price">US $79.99</div>
                                <img src="//ae01.alicdn.com/kf/HTB1Awaxezgy_uJjSZKz762_jXXau.png" data-label-img="//ae01.alicdn.com/kf/Ha570161704134ccebd67d07c6781db1ej.jpg_200x200.jpg"/>
                            </div>
                        </a>
                    </div>
                            </div>

        </div>
            <div class="right-banner" data-spm="5">
            <a href="https://sale.aliexpress.com/newuser_zone.htm" target="_blank">
                <img class="coupon-banner" src="//ae01.alicdn.com/kf/HTB1Awaxezgy_uJjSZKz762_jXXau.png" data-right-banner="//ae01.alicdn.com/kf/H64b99d97b58c4f61982cf76eef94d2a2K.png" alt="" width="240" height="auto"/>
            </a>
        </div>
    </div>
    <!-- banner end -->
</div>
</div>

<footer class="-pbm -fs12 -bg-gy75 -gy3">
    <div class="-bg-gy8 -mbm">
        <div class="row -pvl">
            <div class="col4">
                <svg viewBox="0 0 138 32" class="ic" width="140" height="32">
                    <use xlink:href="https://www.jumia.com.gh/assets_he/images/i-shop-jumia.c8de1c55.svg#logo-inv"></use>
                </svg>
            </div>
            <div class="col7 -df -d-co -j-bet">
                <div>
                    <div class="f-t -pbs">New to Jumia?</div>Subscribe to our newsletter to get updates on our latest offers!</div>
                <form method="post" id="nl-ft-f" action="/newsletter/subscription/default/" class="nl-form _ftr -ptm">
                    <div class="-df -i-start">
                        <div class="nl-fi-w -mrs -fg1">
                            <label class="nl-lbl -vh-sr" for="fi-nl-ft-email">form_email-label</label>
                            <input id="fi-nl-ft-email" class="nl-fi" type="email" name="email" placeholder="Enter E-mail Address" value required />
                            <svg viewBox="0 0 24 24" class="ic -f-gy3" width="18" height="18">
                                <use xlink:href="https://www.jumia.com.gh/assets_he/images/i-icons.14592adc.svg#email"></use>
                            </svg>
                        </div>
                        <div class="-df">
                            <button name="gender" value="male" class="nl-btn brd-btn _sqr -phm">Male</button>
                            <button name="gender" value="female" class="nl-btn brd-btn _sqr -phm">Female</button>
                        </div>
                    </div>
                    <input name="csrfToken" value="c8ba04e73a0f541a813b6f231f39ecdc" type="hidden" />
                </form>
            </div>
            <div class="col4 -mla">
                <div class="-df">
                    <svg viewBox="0 0 40 40" class="ic -fsh0" width="40" height="40">
                        <use xlink:href="https://www.jumia.com.gh/assets_he/images/i-shop-jumia.c8de1c55.svg#app"></use>
                    </svg>
                    <div class="-plm">
                        <div class="f-t -pbs">DOWNLOAD JUMIA FREE APP</div>Get access to exclusive offers!</div>
                </div>
                <div class="-df -ptm">
                    <a href="https://itunes.apple.com/us/app/jumia-online-shopping/id925015459?mt=8" title="Get it on the App Store" class="brd-btn _sqr ic-link -paxs -dif -mrs" target="_blank" rel="nofollow noopener">
                        <svg viewBox="0 0 88 24" class="ic" width="88" height="22">
                            <use xlink:href="https://www.jumia.com.gh/assets_he/images/i-global.663ccf3f.svg#appstore"></use>
                        </svg>
                    </a>
                    <a href="https://play.google.com/store/apps/details?id=com.jumia.android&amp;hl=en" title="Get it on Google Play" class="brd-btn _sqr ic-link -paxs -dif" target="_blank" rel="nofollow noopener">
                        <svg viewBox="0 0 93 23" class="ic" width="93" height="22">
                            <use xlink:href="https://www.jumia.com.gh/assets_he/images/i-global.663ccf3f.svg#googleplay"></use>
                        </svg>
                    </a>
                </div>
            </div>
        </div>
    </div>
    <div class="row -pbl">
        <div class="col4 -df -d-co -pvs"><span class="f-t -pbm">LET US HELP YOU</span>
            <ul class="-lsn">
                <li><a class="_link -pbxs" href="https://www.jumia.com.gh/help/">Help Center</a></li>
                <li><a class="_link -pbxs" href="https://www.jumia.com.gh/contact/">Contact us</a></li>
                <li><a class="_link -pbxs" href="https://www.jumia.com.gh/howtoorder/">How to buy on Jumia</a></li>
                <li><a class="_link -pbxs" href="https://www.jumia.com.gh/shipping/">Delivery timelines and fees</a></li>
                <li><a class="_link -pbxs" href="https://www.jumia.com.gh/returns-refunds-cp/">Return Policy</a></li>
                <li><a class="_link -pbxs" href="https://www.jumia.com.gh/b2bsales/">Corporate and Bulk Purchases</a></li>
            </ul>
        </div>
        <div class="col4 -df -d-co -pvs"><span class="f-t -pbm">ABOUT JUMIA GHANA</span>
            <ul class="-lsn">
                <li><a class="_link -pbxs" href="https://www.jumia.com.gh/about_us/">About us</a></li>
                <li><a class="_link -pbxs" href="https://www.jumia.com.gh/testimonials/">Testimonials</a></li>
                <li><a class="_link -pbxs" href="https://www.jumia.com.gh/careers/">Jumia careers</a></li>
                <li><a class="_link -pbxs" href="https://www.jumia.com.gh/terms-and-conditions/">Terms and Conditions</a></li>
                <li><a class="_link -pbxs" href="https://www.jumia.com.gh/privacy/">Privacy Policy</a></li>
            </ul>
        </div>


    </div>
    <div class="row -pbl">
        <div class="col4 row">
            <div class="f-t col16 -pbm">JOIN US ON</div>
            <div class="col16 -phn -fs0">
                <a href="https://www.facebook.com/jumiaghana/" title="Facebook Jumia Ghana" class="ic-link -pas" target="_blank" rel="noopener">
                    <svg viewBox="0 0 24 24" class="ic" width="26" height="26">
                        <use xlink:href="https://www.jumia.com.gh/assets_he/images/i-icons.14592adc.svg#soc-facebook"></use>
                    </svg>
                </a>
                <a href="https://twitter.com/JumiaGhana/" title="Instagram Jumia Ghana" class="ic-link -pas" target="_blank" rel="noopener">
                    <svg viewBox="0 0 24 24" class="ic" width="26" height="26">
                        <use xlink:href="https://www.jumia.com.gh/assets_he/images/i-icons.14592adc.svg#soc-instagram"></use>
                    </svg>
                </a>
                <a href="https://www.instagram.com/jumiaghana/" title="Twitter Jumia Ghana" class="ic-link -pas" target="_blank" rel="noopener">
                    <svg viewBox="0 0 24 24" class="ic" width="26" height="26">
                        <use xlink:href="https://www.jumia.com.gh/assets_he/images/i-icons.14592adc.svg#soc-twitter"></use>
                    </svg>
                </a>
            </div>
        </div>
        <div class="col4 -df -d-co"><span class="f-t">Contact us</span>
            <div class="-fs14 -ptxl">030 274 0630</div>
        </div>
        <div class="col8 row">
            <div class="f-t col16 -pbm">PAYMENT METHODS</div>
            <div class="col16 -phn -df -fw-w">
                <a href="https://www.jumia.com.gh/how-to-pay/" title="Payment on delivery" class="ic-link -pas">
                    <svg viewBox="0 0 24 24" class="ic" width="24" height="24">
                        <use xlink:href="https://www.jumia.com.gh/assets_he/images/i-global.663ccf3f.svg#pay-cashondelivery"></use>
                    </svg>
                </a>
                <a href="https://www.jumia.com.gh/how-to-pay/" title="Visa" class="ic-link -pas">
                    <svg viewBox="0 0 31 24" class="ic" width="31" height="24">
                        <use xlink:href="https://www.jumia.com.gh/assets_he/images/i-global.663ccf3f.svg#pay-visa"></use>
                    </svg>
                </a>
                <a href="https://www.jumia.com.gh/how-to-pay/" title="Mastercard" class="ic-link -pas">
                    <svg viewBox="0 0 36 24" class="ic" width="36" height="24">
                        <use xlink:href="https://www.jumia.com.gh/assets_he/images/i-global.663ccf3f.svg#pay-mastercard"></use>
                    </svg>
                </a>
                <a href="https://www.jumia.com.gh/how-to-pay/" title="Mobile Money" class="ic-link -pas"></a>
            </div>
        </div>
    </div>
    <div class="vb row -i-ctr -j-ctr _foot _gy7 -hr -gy3 -mtl">
        <div class="col3 -df -j-start"></div>
        <div class="col10 -df -j-ctr -fs0">
            <a class="vent-link" title="Jumia Food" href="https://food.jumia.com.gh/?utm_source=jumia&amp;utm_medium=mall&amp;utm_campaign=venturebar" rel="nofollow noopener" target="_blank">
                <svg viewBox="0 0 70 24" class="ic" width="70" height="24">
                    <use xlink:href="https://www.jumia.com.gh/assets_he/images/i-global.663ccf3f.svg#venture-food"></use>
                </svg>
            </a>
            <a class="vent-link" title="Jumia Travel" href="https://hotel.travelstart.com/destinations/ghana/hub.aspx?currencyCode=USD&amp;source=9927&amp;utm_source=Partnership&amp;utm_medium=Jumia&amp;utm_campaign=Jumia_Travel" rel="nofollow noopener" target="_blank">
                <svg viewBox="0 0 83 24" class="ic" width="83" height="24">
                    <use xlink:href="https://www.jumia.com.gh/assets_he/images/i-global.663ccf3f.svg#venture-travel"></use>
                </svg>
            </a>
            <a class="vent-link" title="Jumia Flights" href="https://travelstart.com/?utm_source=jumia&amp;utm_medium=JumiaTravelstart&amp;utm_campaign=flights" rel="nofollow noopener" target="_blank">
                <svg viewBox="0 0 88 24" class="ic" width="88" height="24">
                    <use xlink:href="https://www.jumia.com.gh/assets_he/images/i-global.663ccf3f.svg#venture-flights"></use>
                </svg>
            </a>
            <a class="vent-link" title="Jumia Party" href="https://party.jumia.com.gh/?utm_source=jumia&amp;utm_medium=mall&amp;utm_campaign=venturebar" rel="nofollow noopener" target="_blank">
                <svg viewBox="0 0 80 24" class="ic" width="80" height="24">
                    <use xlink:href="https://www.jumia.com.gh/assets_he/images/i-global.663ccf3f.svg#venture-jumia-party"></use>
                </svg>
            </a>
            <a class="vent-link" title="Jumia One" href="https://one.jumia.com.gh/?utm_source=jumia&amp;utm_medium=mall&amp;utm_campaign=venturebar" rel="nofollow noopener" target="_blank">
                <svg viewBox="0 0 56 24" class="ic" width="56" height="24">
                    <use xlink:href="https://www.jumia.com.gh/assets_he/images/i-global.663ccf3f.svg#venture-jumia-one"></use>
                </svg>
            </a>
        </div>
        <div class="col3 -df -j-end -wt -mla"></div>
    </div>
</footer>



<!--
    *
    *
    *
    *
    *
    *
    *
    *
    *
    *
    *
    *
    *
    *
    *
    *
    *
    *
    *
    *
    *
    *
    *
    *
    *
    *
    *
    *
    *
    *
    *
    *
    *
    *
    *
    *
    *
    *
    *
    *
    ****************from is the link ref css from the index page dump********************************* -->




<link rel="canonical" href="https://www.aliexpress.com/">
    <link rel="shortcut icon" href="//ae01.alicdn.com/images/eng/wholesale/icon/aliexpress.ico" type="image/x-icon"/>
    <link href="android-app://com.alibaba.aliexpresshd/aliexpress/deeplink/home/www/en" hreflang="en"  
          rel="alternate"/>
    <link rel="stylesheet" type="text/css" href="//i.alicdn.com/ae-affiliate-ui/home/united/??home.94770ab2.css">
