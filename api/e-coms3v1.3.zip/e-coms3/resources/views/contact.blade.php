@extends('master.app')
@section('content')

<h1>contact</h1>
@endsection
