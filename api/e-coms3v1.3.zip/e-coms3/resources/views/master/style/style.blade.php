<style type="text/css">



  /**account modal starts*/

    .help-tip {
      color: #ccc;
      margin-bottom: 20px;
    }
    .modal-header {
      background: #EA8005;
    }
    .modal-header h4.modal-title {
      color: #fff;
    }
    .modal-body label {
      color: #5e5e5e;
    }
    .btn {
      /*border-width: 0;*/
      text-decoration: none;
      font-family: 'Roboto Condensed', sans-serif;
      -webkit-transition: all 0.3s ease 0.2s;
      -moz-transition: all 0.3s ease 0.2s;
      -ms-transition: all 0.3s ease 0.2s;
      -o-transition: all 0.3s ease 0.2s;
      transition: all 0.3s ease 0.1s;
      text-transform: uppercase;
      border-radius: 3px;
      -webkit-border-radius: 3px;
      -moz-border-radius: 3px;
      -ms-border-radius: 3px;
      -o-border-radius: 3px;
    }
    .btn-primary {
      background: #EA8005;
      color: #fff;
      border: 1px solid #c5c5c5;
    }
    .btn-primary:hover,
    .btn-primary:focus {
      background: #c5c5c5;
      border-color: #777777;
    }
    .btn-primary:active {
      box-shadow: inset 0 3px 3px rgba(0,0,0,0.1);
      border-color: #EA8005;
    }
    .btn-primary[disabled] {
      background: #EA8005;
      border-color: #c5c5c5;
    }

    #slydepay-logo {
      background: url(images/slydepay-logo-grey.png) no-repeat;
      width: 150px;
      height: 50px;
      -webkit-transition: all 0.3s ease 0.2s;
      -moz-transition: all 0.3s ease 0.2s;
      -ms-transition: all 0.3s ease 0.2s;
      -o-transition: all 0.3s ease 0.2s;
      transition: all 0.3s ease 0.1s;
    }
    #slydepay-logo:hover {
      background: url(images/slydepay-logo.png) no-repeat;
    }
    .form-control.error,
    label.error {
      color: #f14f5b;
      border-color: #f14f5b;
      font-weight: 100;
    }

   .btn-primary{
        background-color: rgb(42, 151, 153);
        margin: 5;/*
            width: 27%;
    font-size: 1.3rem;*/

    }
    div.card{

    margin-bottom: 10px;
}


    .btn-primary.register{
         color: rgb(42, 151, 153);
         background-color: white;

    }

    /**account modal ends*/
            div.modal-content {
                            width: 200%;

                        }

div.header-logo a.logo1 img {
    max-width: 90px;
    max-height: 90px;
}




    .flyout-user-signIn a.sign-btn {
    background-color: #FFF1F1;
    color: rgb(42, 151, 153);
    }
    .flyout-user-signIn a.sign-btn:hover{
        background-color: rgb(42, 151, 153);
        color:white;

    }


.flyout-user-signIn a.join-btn:hover {
    background-color: #FFF1F1;
    color: rgb(42, 151, 153);
}
div.ng-item.ng-help.ng-sub span.ng-sub-title:hover{
    color:  rgb(42, 151, 153);

}

div.nav-global .ng-mobile a::before{
   /* color:  rgb(42, 151, 153);  */
   color: green;

}
div.nav-global .ng-mobile a:hover{
    color:  rgb(42, 151, 153);
}
.nav-global:hover{
    color:  rgb(42, 151, 153);
}
.nav-global .nav-wishlist .text:hover{
    color:  rgb(42, 151, 153);
}

.nav-user-account .user-account-port .text:hover{
    color:  rgb(42, 151, 153);
}
/*
div:hover:before:hover{

}
*/
div.nav-global .ng-mobile a::before{
    color:  rgb(42, 151, 153);
}


.slick-initialized .slick-slide {
    display: block;
}
.slick-slide {
    display: none;
    float: left;
    height: 60%;
    min-height: 1px;
}

      .nav-global .ng-icon-size {
          margin-top: 1px;
        position: relative;   }



 a.btn.btn-outline-primary.float.right:hover{
  color: white;
background-color:  rgb(42, 151, 153);
  }



input#input_search.input{
    width: 300px;
  border-radius: 30px 1px  1px 30px;

 }


         div.modal-body button.close  {
                                            right: 2;
                                            margin-top: -1px;
                                            position: fixed;
                                            float: right;
                                            font-size: 1.3rem;
                                            font-weight: 500;
                                            line-height: 1;
                                            z-index: 20000;
                                            color: #000;
                                            text-shadow: 0 1px 0 #fff;
                                            opacity: 0.7;

                                    }
     .modal-content  {
    -webkit-border-radius: 0px !important;
    -moz-border-radius: 0px !important;
    border-radius: 0px !important;

    }
        .modal-body{
        position: relative;
    -webkit-box-flex: 1;
    -ms-flex: 1 1 auto;
    flex: 1 1 auto;
    padding: 0;
}

/**chat bot**/
 body {font-family: Arial, Helvetica, sans-serif;}
    * {box-sizing: border-box;}

    /* Button used to open the chat form - fixed at the bottom of the page */
    .open-button {
      background-color: rgb(42, 151, 153);
      color: white;
      padding: 16px 20px;
      border: none;
      cursor: pointer;
      opacity: 0.8;
      position: fixed;
      bottom: 23px;
      right: 15px;
      width: 240px;
      border-radius: 10px;
      z-index: 3000;

    }

    /* The popup chat - hidden by default */
    .chat-popup {
        background-image: url(img/bg.png)
      display: none;
      position: fixed;
      bottom: 0;
      right: 15px;
      border: 3px solid #f1f1f1;
      z-index: 90000;
      border-radius: 20px 20px 10px 1px;
    }

    form#chatmessage.form-container label{
        color: rgb(42, 151, 173);
        font-size: 1.3rem;

    }
    form#chatmessage.form-container h3{
        color:  rgb(42, 151, 163);
    }

    /* Add styles to the form container */
    .form-container {
      max-width: 300px;
      padding: 10px;
      background-color: white;
      height: 350px;
    margin-bottom: 0px;
    border-radius: 20px 20px 1px 1px;

    }

    /* Full-width textarea */
    .form-container textarea {
      width: 100%;
      padding: 15px;
      margin: 5px 0 22px 0;
      border: none;
      background: #f1f1f1;
      resize: none;
      min-height: 120px;
      margin-bottom: 80px;
      z-index: 3000;

    }

    /* When the textarea gets focus, do something */
    .form-container textarea:focus {
      background-color: #ddd;
      outline: none;
    }

    /* Set a style for the submit/send button */
    .form-container .btn {
      background-color: white;
      color: rgb(42, 151, 153);
      padding: 16px 20px;
      border: none;
      cursor: pointer;
      width: 138px;
      margin-bottom:10px;
      opacity: 0.8;
      border-radius: 5px;
      z-index: 3000;
      font-size: 1.3rem;
    font-weight: 300;
    margin-bottom: 10px;
    height: 2.7em;
    }

    /* Add a red background color to the cancel button */
    .form-container .cancel {
      background-color: rgb(42, 151, 153);
      color: white;
      z-index: 3000;
      width: 138px;
      margin-bottom: 10px;
    height: 2.7em;
    }

    /* Add some hover effects to buttons */
    .form-container .btn:hover, .open-button:hover {
      opacity: 1;
    }



 @media only screen and (min-width: 991px) {

     div.modal-body button.close  {
            font-size: 2.4rem;
          font-weight: 800;

     }

 @media only screen and (max-width: 991px) {
          input#input_search.input{
              width: 200px;
             border-radius: 30px 1px  1px 30px;

                         }

                                    }



                      @media only screen and (max-width: 579px) {
                             /*search input*/
                        input#input_search.input{
                                width: 160px;
                                border-radius: 30px 1px  1px 30px;
                                margin-top: -6px;

                                    }
                                            /*wishlist icon*/
                                    .nav-global .ng-icon-size{
                                    margin-top: 13px;
                                    position: relative;
                                        }

                                    div.header-ctn div.wish{
                                     position: absolute;
                                     left: 1;
                                     top: 32;
                                    }

                    header.header-section{
                    height: 100px;

                        }

                    div#header{
                height: 100px;
                    }


                             /*logo*/
                        div.header-logo a.logo1 img {
                            position: absolute;
                            max-width: 40px;
                        max-height: 40px;
                        margin-top: 70px;
                            left: 50%;
                            display: none;
                            }
                            div.header-ctn div.wish{
                                display: none;
                            }
                            div.header-ctn div.dropdown{
                                display: none;
                            }
                            [class*='col-xs'] {
                                width: 100%;
                               height: 35%;
                        }
                        h3.section-title{
                            margin-top: 100px;
                            color:  rgb(42, 151, 153);
                            font-weight: 200px;
                        }


                    }































</style>
