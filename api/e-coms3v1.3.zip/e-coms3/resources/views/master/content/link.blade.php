     <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
     
       {{-- alibaba header --}}
     <link href="//i.alicdn.com/ae-header/20191217202516/buyer/glofront/ae-header.css" rel="stylesheet" type="text/css" />



     <!-- Css Styles -->
     <!-- navbar search area -->
     <link rel="stylesheet" href="https://rawgit.com/lykmapipo/themify-icons/master/css/themify-icons.css"  type="text/css">
     <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
     <link rel="stylesheet" href="css/elegant-icons.css" type="text/css">
     <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
     <link rel="stylesheet" href="css/nice-select.css" type="text/css">
     <link rel="stylesheet" href="css/jquery-ui.min.css" type="text/css">
     <link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
     <link rel="stylesheet" href="css/style.css" type="text/css">
     <link rel="stylesheet" href="css/testcss.css" type="text/css">
     <link rel="stylesheet" href="css/electro.css" type="text/css">
     <link type="text/css" rel="stylesheet" href="css/slick.css"/>
     <link type="text/css" rel="stylesheet" href="css/slick-theme.css"/>

     <!-- nouislider -->
     <link type="text/css" rel="stylesheet" href="css/nouislider.min.css"/>

     <!-- dollar -->
     <link rel="stylesheet" href="css/dollar/responsive.css">
     <link rel="stylesheet" href="css/dollar/ui.css">
     <link rel="stylesheet" href="css/dollar/inter.css">

     <!-- jquery ui -->
     <link href="css/jquery-ui.css" rel="stylesheet">
     <link href="css/jquery-ui.min.css" rel="stylesheet">
     <link href="css/jquery-ui.structure.css" rel="stylesheet">
     <link href="css/jquery-ui.structure.min.css" rel="stylesheet">
     <link href="css/jquery-ui.theme.css" rel="stylesheet">
     <link href="css/jquery-ui.theme.min.css" rel="stylesheet">


