<div class="chatpane" style="display:none">


<button class="open-button" id="thebutton"  data-toggle="modal" data-target="#1_ModalCenter" onclick="openForm()">Chat</button>

<div class="chat-popup" id="myForm" style="background-image:url(img/bg.png)">
  <form action="" id="chatmessage" class="form-container" style="background-image:url(img/bg.png)">
    <h3>Hello</h3>

    <label for="msg"><b>How may I assist you?</b></label>
    <textarea placeholder="Type message.." name="msg" required></textarea>
    <button type="submit" class="btn">Send</button>
    <button type="button" class="close btn cancel" onclick="closeForm()">Close</button>
  </form>
</div>
</div>

<div class="modal fade" id="1_ModalCenter" tabindex="-1" role="dialog" aria-labelledby="1_ModalCenterTitle" aria-hidden="true">
</div>
