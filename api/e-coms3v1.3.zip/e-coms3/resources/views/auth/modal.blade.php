<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Sign In</title>

    <!-- Bootstrap -->
    <link href="css/font-awesome.min.css" rel="stylesheet">

    <link href="css/ladda-themeless.min.css" rel="stylesheet">


    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">


  </head>
  <body style="  background-color: black">



  <style type="text/css">
    .help-tip {
      color: #ccc;
      margin-bottom: 20px;
    }
    .modal-header {
      background: #EA8005;
    }
    .modal-header h4.modal-title {
      color: #fff;
    }
    .modal-body label {
      color: #5e5e5e;
    }
    .btn {
      /*border-width: 0;*/
      text-decoration: none;
      font-family: 'Roboto Condensed', sans-serif;
      -webkit-transition: all 0.3s ease 0.2s;
      -moz-transition: all 0.3s ease 0.2s;
      -ms-transition: all 0.3s ease 0.2s;
      -o-transition: all 0.3s ease 0.2s;
      transition: all 0.3s ease 0.1s;
      text-transform: uppercase;
      border-radius: 3px;
      -webkit-border-radius: 3px;
      -moz-border-radius: 3px;
      -ms-border-radius: 3px;
      -o-border-radius: 3px;
    }
    .btn-primary {
      background: #EA8005;
      color: #fff;
      border: 1px solid #c5c5c5;
    }
    .btn-primary:hover,
    .btn-primary:focus {
      background: #c5c5c5;
      border-color: #777777;
    }
    .btn-primary:active {
      box-shadow: inset 0 3px 3px rgba(0,0,0,0.1);
      border-color: #EA8005;
    }
    .btn-primary[disabled] {
      background: #EA8005;
      border-color: #c5c5c5;
    }

    #slydepay-logo {
      background: url(images/slydepay-logo-grey.png) no-repeat;
      width: 150px;
      height: 50px;
      -webkit-transition: all 0.3s ease 0.2s;
      -moz-transition: all 0.3s ease 0.2s;
      -ms-transition: all 0.3s ease 0.2s;
      -o-transition: all 0.3s ease 0.2s;
      transition: all 0.3s ease 0.1s;
    }
    #slydepay-logo:hover {
      background: url(images/slydepay-logo.png) no-repeat;
    }
    .form-control.error,
    label.error {
      color: #f14f5b;
      border-color: #f14f5b;
      font-weight: 100;
    }

   .btn-primary{
        background-color: rgb(42, 151, 153);
        margin: 5;/*
            width: 27%;
    font-size: 1.3rem;*/

    }
    div.card{

    margin-bottom: 10px;
}


    .btn-primary.register{
         color: rgb(42, 151, 153);
         background-color: white;

    }
  </style>
    <div class="modal fade in" id="sponsorModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="false" style="display: block;">
      <div class="modal-dialog  modal-lg">
        <form class="form-horizontal" id="donationForm">
          <div class="modal-content">
            <div class="modal-header" style=" background-color: rgb(42, 151, 173);">
                 <h4 class="modal-title" id="myModalLabel">Sign In To Tuatuagye</h4>
              <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>

            </div>


            <div class="modal-body">

   <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">{{ __('Login') }}</div>

                <div class="card-body">
                    <form method="POST" action="{{ route('login') }}">
                        @csrf

                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right">{{ __('E-Mail Address') }}</label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" required autocomplete="email" autofocus>

                                @error('email')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password" class="col-md-4 col-form-label text-md-right">{{ __('Password') }}</label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control @error('password') is-invalid @enderror" name="password" required autocomplete="current-password">

                                @error('password')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="form-group row">
                            <div class="col-md-6 offset-md-4">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="remember" id="remember" {{ old('remember') ? 'checked' : '' }}>

                                    <label class="form-check-label" for="remember">
                                        {{ __('Remember Me') }}
                                    </label>
                                </div>
                            </div>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-8 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    {{ __('Login') }}
                                </button>

                                @if (Route::has('password.request'))
                                    <a class="btn btn-link" href="{{ route('password.request') }}">
                                        {{ __('Forgot Your Password?') }}
                                    </a>
                                @endif
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>


          </div><!-- /.modal-content -->
        </form>
      </div><!-- /.modal-dialog -->
    </div>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="js/modal/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <script src="js/modal/jquery.validate.min.js"></script>
    <script src="js/modal/spin.min.js"></script>
    <script src="js/modal/ladda.min.js"></script>

        <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <!-- Include all compiled plugins (below), or include individual files as needed -->


    <script>
      $(document).ready(function() {
        $('#sponsorModal').modal({
          keyboard: false,
          backdrop: 'static'
        });

        var l;

        $('#submitDonation').bind('click', function(e) {
          e.preventDefault();
          l = Ladda.create(this);
          var btn = $(this);

          $.validator.setDefaults({
            rules: {
              donationAmount: {
                required: true,
                digits: true
              },
              sponsorMobile: {
                required: true,
                digits: true
              }
            }
          });

          if ( $('#donationForm').valid() ) {
            $('#donationForm').validate().focusInvalid();
            processDonation();
          }
        });





        function processDonation() {
          var formData = {
            donationCurrency: $('#donationCurrency').val(),
            donationAmount: $('#donationAmount').val(),
            sponsorName: $('#sponsorName').val(),
            sponsorEmail: $('#sponsorEmail').val(),
            sponsorMobile: $('#sponsorMobile').val(),
            sponsorShowName: $('#sponsorShowName').is(':checked')
          }
          console.log(formData);
          l.start();
          $.ajax({
            url : "slydepay_buy.php",
            type: "POST",
            data : formData,
            success: function(data, textStatus, jqXHR)
            {
             window.location = data;

            },
            error: function (jqXHR, textStatus, errorThrown)
            {
              alert(errorThrown);
              l.stop();
            }
          });
        }
      });
    </script>


  </body>
</html>
