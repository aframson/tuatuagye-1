@extends('frontend.master.app')
{!! '<h2>index page!</h2>' !!}


@section('content')

@endsection
