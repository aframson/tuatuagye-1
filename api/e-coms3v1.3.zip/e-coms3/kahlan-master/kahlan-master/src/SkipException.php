<?php
namespace Kahlan;

class SkipException extends \RuntimeException
{
}
