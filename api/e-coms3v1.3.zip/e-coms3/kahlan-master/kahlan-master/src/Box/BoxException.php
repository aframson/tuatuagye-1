<?php
namespace Kahlan\Box;

class BoxException extends \RuntimeException
{
    protected $code = 500;
}
