<?php
namespace Kahlan;

class QuitException extends \Exception
{
}
