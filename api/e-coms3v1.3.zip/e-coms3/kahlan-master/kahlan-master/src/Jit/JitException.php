<?php
namespace Kahlan\Jit;

class JitException extends \Exception
{
    protected $code = 500;
}
