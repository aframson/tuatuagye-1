<?php
namespace Kahlan\Code;

class TimeoutException extends \Exception
{
}
