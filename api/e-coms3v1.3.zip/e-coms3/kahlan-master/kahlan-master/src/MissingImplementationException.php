<?php
namespace Kahlan;

class MissingImplementationException extends \Exception
{
}
