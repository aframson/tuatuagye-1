<?php
new space\MyClass2(time();
