<?php
declare(strict_types = 1);

function value(): int {
    return 15;
}

echo 'Hello';
