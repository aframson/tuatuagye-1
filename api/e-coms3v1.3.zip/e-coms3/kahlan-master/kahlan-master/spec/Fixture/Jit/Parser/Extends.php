<?php
namespace Test;

use Some\Name\Space;

class A extends \Space\ParentA {

}

class B extends Space\ParentB {

}

class C extends Space {

}

class D extends ParentD {

}

class E {

}
