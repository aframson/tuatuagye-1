<?php
namespace Kahlan\Spec\Fixture\Jit\Patcher\Layer;

class Inspector extends \Kahlan\Analysis\Inspector
{

}
