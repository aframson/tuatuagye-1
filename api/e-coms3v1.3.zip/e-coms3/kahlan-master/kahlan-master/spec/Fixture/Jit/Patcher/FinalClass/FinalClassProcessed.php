<?php
namespace FakeNamespace;

class FinalClass
{
    public function hello()
    {
        return 'Hello World';
    }
}
