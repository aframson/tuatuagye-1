<?php
namespace Kahlan\Spec\Fixture\Jit\Interceptor;

class ClassE {

}
