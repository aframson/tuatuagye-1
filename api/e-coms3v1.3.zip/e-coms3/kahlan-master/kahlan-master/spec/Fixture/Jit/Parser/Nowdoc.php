<?php

$code = <<<'EOT'
    time();
EOT;
