<?php
define('PI', '3.14');

function myFunction($required, $param = "value", $boolean = false, $array = [], $array2 = array(), $constant = PI) {

}