<?php
use name\space\MyClass as MyAlias;
use name\space as space;

if (function_exists('myfunction')) {
    $thatIsWeird = true;
}

$rand = mt_rand();
new MyAlias;
new space\MyClass2(time());
