<?php $__KMONKEY__0=\Kahlan\Plugin\Monkey::patched(__NAMESPACE__ , null, 'time', $__KMONKEY__0__);$__KMONKEY__1=\Kahlan\Plugin\Monkey::patched(__NAMESPACE__, 'space\MyClass2', null, $__KMONKEY__1__); ?><?php
new $__KMONKEY__1($__KMONKEY__0();
