<?php
namespace Kahlan\Spec\Fixture\Jit\Interceptor;

class ClassToCache {

}
