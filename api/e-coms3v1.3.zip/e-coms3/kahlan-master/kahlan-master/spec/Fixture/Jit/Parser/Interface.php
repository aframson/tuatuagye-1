<?php

namespace App;

interface DependencyInterface
{
    public function process($param);
}
