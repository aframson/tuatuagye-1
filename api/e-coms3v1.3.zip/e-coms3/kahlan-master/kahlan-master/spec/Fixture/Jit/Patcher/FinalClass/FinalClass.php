<?php
namespace FakeNamespace;

final class FinalClass
{
    public function hello()
    {
        return 'Hello World';
    }
}
