<?php
namespace Test;

use Some\Name\Space;

class A implements \Space\ParentA {

}

class B implements Space\ParentB {

}

class C implements ParentC {

}

class D implements ParentD1, ParentD2, ParentD3 {

}

class E {

}
