<?php
declare(ticks=1) {
    echo "Ticked";
}

for($i = 0; $i < 10; $i++) {
    echo "Success";
}
