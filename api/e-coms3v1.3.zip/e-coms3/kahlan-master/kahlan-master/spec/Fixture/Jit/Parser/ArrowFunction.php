<?php
define('PI', '3.14');

fn($required, $param = "value", $boolean = false, $array = [], $array2 = array(), $constant = PI) => null;
$i = 0;