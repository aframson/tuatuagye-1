<?php
declare(strict_types=1);$__KMONKEY__0=\Kahlan\Plugin\Monkey::patched(null, 'My\Name\Space\MyClass', null, $__KMONKEY__0__);

use My\Name\Space\MyClass;

$instance = ($__KMONKEY__0__?$__KMONKEY__0__:new $__KMONKEY__0());
