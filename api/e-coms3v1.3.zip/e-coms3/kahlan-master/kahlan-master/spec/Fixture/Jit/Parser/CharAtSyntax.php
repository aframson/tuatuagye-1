<?php
$mystring[0];
$mystring[5];
$mystring{0};
$mystring{5};
