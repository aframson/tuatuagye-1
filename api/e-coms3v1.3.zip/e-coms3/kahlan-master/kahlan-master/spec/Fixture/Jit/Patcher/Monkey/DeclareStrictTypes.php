<?php
declare(strict_types=1);

use My\Name\Space\MyClass;

$instance = new MyClass();
