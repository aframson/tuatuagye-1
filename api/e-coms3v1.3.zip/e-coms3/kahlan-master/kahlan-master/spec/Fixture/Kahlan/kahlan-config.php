<?php
use Kahlan\Cli\CommandLine;

$commandLine = new CommandLine();
$this->suite()->loaded = true;
