<?php
$message = 'Hello World';
$variable = <<<EOT
    echo "{$message}";
EOT;
