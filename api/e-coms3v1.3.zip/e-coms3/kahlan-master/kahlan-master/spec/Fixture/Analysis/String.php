<?php

$message = 'hello';
echo "{$message}";

$message = 'multi
    line
    message
';

$message = "Hello
world";

echo $message;
