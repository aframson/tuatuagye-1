<?php
namespace Kahlan\Spec\Fixture\Analysis;

use Exception;

class ScalarTypeHintsClass {

    public function intTypeHint(int $values) {
    }

    public function boolTypeHint(bool $values) {
    }

}
