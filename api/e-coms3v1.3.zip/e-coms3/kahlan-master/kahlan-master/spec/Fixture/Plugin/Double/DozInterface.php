<?php
namespace Kahlan\Spec\Fixture\Plugin\Double;

interface DozInterface
{
    public function foo($a);
    public function bar($b = null);
}
