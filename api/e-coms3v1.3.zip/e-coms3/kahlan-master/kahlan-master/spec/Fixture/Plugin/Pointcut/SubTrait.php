<?php
namespace Kahlan\Spec\Fixture\Plugin\Pointcut;

trait SubTrait
{
    public function traitMethod()
    {
        return 'traitMethod';
    }
}
