<?php
namespace Kahlan\Spec\Fixture\Reporter\Coverage;

interface ImplementsCoverageInterface
{
    public function foo($a);
}
