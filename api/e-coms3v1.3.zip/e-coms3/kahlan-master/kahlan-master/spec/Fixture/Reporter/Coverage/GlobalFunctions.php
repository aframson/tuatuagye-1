<?php
function shallNotPass()
{
    $shallNotPass = false;
    if (false) {
        $shallNotPass = true;
    }
    return $shallNotPass;
    $shallNotPass = true;
}
