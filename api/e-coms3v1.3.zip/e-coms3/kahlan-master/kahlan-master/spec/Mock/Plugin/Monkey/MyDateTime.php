<?php
namespace Kahlan\Spec\Mock\Plugin\Monkey;

class MyDateTime
{
    public function getTimestamp()
    {
        return 245026800;
    }
}
