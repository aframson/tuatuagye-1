<?php
namespace Kahlan\Spec\Mock\Plugin\Double;

trait HelloTrait
{
    public function hello()
    {
        return 'Hello World From Trait!';
    }
}
