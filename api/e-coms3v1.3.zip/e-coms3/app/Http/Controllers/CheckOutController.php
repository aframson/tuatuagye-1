<?php

namespace App\Http\Controllers;
use OVAC\HubtelPayment\Config;
use OVAC\HubtelPayment\Api\Transaction\ReceiveMoney;

use Illuminate\Http\Request;

class CheckOutController extends Controller
{
    //recieves money

    public function someClass(Config $config)
{
    /*
    $receiveMoney = ReceiveMoney::from('0570762862') //- The phone number to send the prompt to.
                ->amount(1.00)                    //- The exact amount value of the transaction
                ->description('Online Purchase')    //- Description of the transaction.
                ->customerEmail('admin@ovac4u.com') //- Name of the person making the payment.
                ->callback('http://ovac4u.com/pay') //- The URL to send callback after payment.
                ->channel('mtn-gh');                //- The mobile network Channel.

    $receiveMoney->injectConfig($config)            //- Inject the configuration
              ->run();

              */
              return 'send money';                          //- Run the transaction after required data.
}


public function verifycus(Request $request)
{
   // $users = User::all(); #grabs all contents of table "message"

 //   session::set('username', $users-> name);
// for regular php expression
       // getphonenumber( $name);
/*
 foreach ($users as $user) {

    $user-> name;  #the name is the placeholder for 1st column in the db
    // $user-> phone_number; echo '<br>  <br>'; #the content is the placeholder for 2nd column in the db



 }
 //echo $check;
*/
 //echo 'the fields in the users table have been echoed right?';  #the name is the placeholder for 1st column in the db
 //protected $redirectTo = RouteServiceProvider::HOME;
 return view('home');
// return view('user.profile',);

}

}





