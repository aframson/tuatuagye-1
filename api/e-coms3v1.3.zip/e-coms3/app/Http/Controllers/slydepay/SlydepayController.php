<?php

namespace App\Http\Controllers\slydepay;

require '../vendor/autoload.php';


use App\Http\Controllers\Controller;
use Illuminate\Http\Request;


use Slydepay;
use Slydepay\Order\Order;
use Slydepay\Order\OrderItem;
use Slydepay\Order\OrderItems;

class SlydepayController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //

        /************************** */








        // Instantiate Slydepay
        $slydepay = new Slydepay\Slydepay("yeboah.determined.isaac@gmail.com", "1575679257987");

    // Create a list of OrderItems with OrderItem objects
    $orderItems = new OrderItems([
    new OrderItem("1234", "Test Product", 10, 2),
    new OrderItem("1284", "Test Product2", 20, 2),
        ]);

    // Shipping and tax pulled either from ini/properties file. Hard coded here for illustration
        $shippingCost = 20;
        $tax = 10;

            // Create the Order object for this transaction.
            $order = Order::createWithId(
                $orderItems,
                "order_id_1",
                $shippingCost,
                $tax,
                "watch",
                "purchase"
            );

        try {
    // Make request to Slydepay and get the response object for the redirect url
    $response = $slydepay->processPaymentOrder($order);
    echo $response->redirectUrl();
} catch (Slydepay\Exception\ProcessPayment $e) {
    echo $e->getMessage();
}





















        /*  ends here **/
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
