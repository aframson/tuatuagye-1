




﻿
<!doctype html>
<html class="no-js">
<head>







    <meta charset="utf-8">
    <title>Slydepay</title>

    <meta HTTP-EQUIV="Pragma" CONTENT="no-cache">
    <meta HTTP-EQUIV="Expires" CONTENT="-1">

    <meta name="description" content="">
    <meta name="viewport" content="width=device-width">

<script type="text/javascript">(window.NREUM||(NREUM={})).loader_config={licenseKey:"e4d65cd08f",applicationID:"69318803"};window.NREUM||(NREUM={}),__nr_require=function(e,n,t){function r(t){if(!n[t]){var i=n[t]={exports:{}};e[t][0].call(i.exports,function(n){var i=e[t][1][n];return r(i||n)},i,i.exports)}return n[t].exports}if("function"==typeof __nr_require)return __nr_require;for(var i=0;i<t.length;i++)r(t[i]);return r}({1:[function(e,n,t){function r(){}function i(e,n,t){return function(){return o(e,[u.now()].concat(f(arguments)),n?null:this,t),n?void 0:this}}var o=e("handle"),a=e(4),f=e(5),c=e("ee").get("tracer"),u=e("loader"),s=NREUM;"undefined"==typeof window.newrelic&&(newrelic=s);var p=["setPageViewName","setCustomAttribute","setErrorHandler","finished","addToTrace","inlineHit","addRelease"],l="api-",d=l+"ixn-";a(p,function(e,n){s[n]=i(l+n,!0,"api")}),s.addPageAction=i(l+"addPageAction",!0),s.setCurrentRouteName=i(l+"routeName",!0),n.exports=newrelic,s.interaction=function(){return(new r).get()};var m=r.prototype={createTracer:function(e,n){var t={},r=this,i="function"==typeof n;return o(d+"tracer",[u.now(),e,t],r),function(){if(c.emit((i?"":"no-")+"fn-start",[u.now(),r,i],t),i)try{return n.apply(this,arguments)}catch(e){throw c.emit("fn-err",[arguments,this,e],t),e}finally{c.emit("fn-end",[u.now()],t)}}}};a("actionText,setName,setAttribute,save,ignore,onEnd,getContext,end,get".split(","),function(e,n){m[n]=i(d+n)}),newrelic.noticeError=function(e,n){"string"==typeof e&&(e=new Error(e)),o("err",[e,u.now(),!1,n])}},{}],2:[function(e,n,t){function r(e,n){var t=e.getEntries();t.forEach(function(e){"first-paint"===e.name?c("timing",["fp",Math.floor(e.startTime)]):"first-contentful-paint"===e.name&&c("timing",["fcp",Math.floor(e.startTime)])})}function i(e,n){var t=e.getEntries();t.length>0&&c("lcp",[t[t.length-1]])}function o(e){if(e instanceof s&&!l){var n,t=Math.round(e.timeStamp);n=t>1e12?Date.now()-t:u.now()-t,l=!0,c("timing",["fi",t,{type:e.type,fid:n}])}}if(!("init"in NREUM&&"page_view_timing"in NREUM.init&&"enabled"in NREUM.init.page_view_timing&&NREUM.init.page_view_timing.enabled===!1)){var a,f,c=e("handle"),u=e("loader"),s=NREUM.o.EV;if("PerformanceObserver"in window&&"function"==typeof window.PerformanceObserver){a=new PerformanceObserver(r),f=new PerformanceObserver(i);try{a.observe({entryTypes:["paint"]}),f.observe({entryTypes:["largest-contentful-paint"]})}catch(p){}}if("addEventListener"in document){var l=!1,d=["click","keydown","mousedown","pointerdown","touchstart"];d.forEach(function(e){document.addEventListener(e,o,!1)})}}},{}],3:[function(e,n,t){function r(e,n){if(!i)return!1;if(e!==i)return!1;if(!n)return!0;if(!o)return!1;for(var t=o.split("."),r=n.split("."),a=0;a<r.length;a++)if(r[a]!==t[a])return!1;return!0}var i=null,o=null,a=/Version\/(\S+)\s+Safari/;if(navigator.userAgent){var f=navigator.userAgent,c=f.match(a);c&&f.indexOf("Chrome")===-1&&f.indexOf("Chromium")===-1&&(i="Safari",o=c[1])}n.exports={agent:i,version:o,match:r}},{}],4:[function(e,n,t){function r(e,n){var t=[],r="",o=0;for(r in e)i.call(e,r)&&(t[o]=n(r,e[r]),o+=1);return t}var i=Object.prototype.hasOwnProperty;n.exports=r},{}],5:[function(e,n,t){function r(e,n,t){n||(n=0),"undefined"==typeof t&&(t=e?e.length:0);for(var r=-1,i=t-n||0,o=Array(i<0?0:i);++r<i;)o[r]=e[n+r];return o}n.exports=r},{}],6:[function(e,n,t){n.exports={exists:"undefined"!=typeof window.performance&&window.performance.timing&&"undefined"!=typeof window.performance.timing.navigationStart}},{}],ee:[function(e,n,t){function r(){}function i(e){function n(e){return e&&e instanceof r?e:e?c(e,f,o):o()}function t(t,r,i,o){if(!l.aborted||o){e&&e(t,r,i);for(var a=n(i),f=v(t),c=f.length,u=0;u<c;u++)f[u].apply(a,r);var p=s[y[t]];return p&&p.push([b,t,r,a]),a}}function d(e,n){h[e]=v(e).concat(n)}function m(e,n){var t=h[e];if(t)for(var r=0;r<t.length;r++)t[r]===n&&t.splice(r,1)}function v(e){return h[e]||[]}function g(e){return p[e]=p[e]||i(t)}function w(e,n){u(e,function(e,t){n=n||"feature",y[t]=n,n in s||(s[n]=[])})}var h={},y={},b={on:d,addEventListener:d,removeEventListener:m,emit:t,get:g,listeners:v,context:n,buffer:w,abort:a,aborted:!1};return b}function o(){return new r}function a(){(s.api||s.feature)&&(l.aborted=!0,s=l.backlog={})}var f="nr@context",c=e("gos"),u=e(4),s={},p={},l=n.exports=i();l.backlog=s},{}],gos:[function(e,n,t){function r(e,n,t){if(i.call(e,n))return e[n];var r=t();if(Object.defineProperty&&Object.keys)try{return Object.defineProperty(e,n,{value:r,writable:!0,enumerable:!1}),r}catch(o){}return e[n]=r,r}var i=Object.prototype.hasOwnProperty;n.exports=r},{}],handle:[function(e,n,t){function r(e,n,t,r){i.buffer([e],r),i.emit(e,n,t)}var i=e("ee").get("handle");n.exports=r,r.ee=i},{}],id:[function(e,n,t){function r(e){var n=typeof e;return!e||"object"!==n&&"function"!==n?-1:e===window?0:a(e,o,function(){return i++})}var i=1,o="nr@id",a=e("gos");n.exports=r},{}],loader:[function(e,n,t){function r(){if(!x++){var e=E.info=NREUM.info,n=d.getElementsByTagName("script")[0];if(setTimeout(s.abort,3e4),!(e&&e.licenseKey&&e.applicationID&&n))return s.abort();u(y,function(n,t){e[n]||(e[n]=t)}),c("mark",["onload",a()+E.offset],null,"api");var t=d.createElement("script");t.src="https://"+e.agent,n.parentNode.insertBefore(t,n)}}function i(){"complete"===d.readyState&&o()}function o(){c("mark",["domContent",a()+E.offset],null,"api")}function a(){return O.exists&&performance.now?Math.round(performance.now()):(f=Math.max((new Date).getTime(),f))-E.offset}var f=(new Date).getTime(),c=e("handle"),u=e(4),s=e("ee"),p=e(3),l=window,d=l.document,m="addEventListener",v="attachEvent",g=l.XMLHttpRequest,w=g&&g.prototype;NREUM.o={ST:setTimeout,SI:l.setImmediate,CT:clearTimeout,XHR:g,REQ:l.Request,EV:l.Event,PR:l.Promise,MO:l.MutationObserver};var h=""+location,y={beacon:"bam.nr-data.net",errorBeacon:"bam.nr-data.net",agent:"js-agent.newrelic.com/nr-1167.min.js"},b=g&&w&&w[m]&&!/CriOS/.test(navigator.userAgent),E=n.exports={offset:f,now:a,origin:h,features:{},xhrWrappable:b,userAgent:p};e(1),e(2),d[m]?(d[m]("DOMContentLoaded",o,!1),l[m]("load",r,!1)):(d[v]("onreadystatechange",i),l[v]("onload",r)),c("mark",["firstbyte",f],null,"api");var x=0,O=e(6)},{}],"wrap-function":[function(e,n,t){function r(e){return!(e&&e instanceof Function&&e.apply&&!e[a])}var i=e("ee"),o=e(5),a="nr@original",f=Object.prototype.hasOwnProperty,c=!1;n.exports=function(e,n){function t(e,n,t,i){function nrWrapper(){var r,a,f,c;try{a=this,r=o(arguments),f="function"==typeof t?t(r,a):t||{}}catch(u){l([u,"",[r,a,i],f])}s(n+"start",[r,a,i],f);try{return c=e.apply(a,r)}catch(p){throw s(n+"err",[r,a,p],f),p}finally{s(n+"end",[r,a,c],f)}}return r(e)?e:(n||(n=""),nrWrapper[a]=e,p(e,nrWrapper),nrWrapper)}function u(e,n,i,o){i||(i="");var a,f,c,u="-"===i.charAt(0);for(c=0;c<n.length;c++)f=n[c],a=e[f],r(a)||(e[f]=t(a,u?f+i:i,o,f))}function s(t,r,i){if(!c||n){var o=c;c=!0;try{e.emit(t,r,i,n)}catch(a){l([a,t,r,i])}c=o}}function p(e,n){if(Object.defineProperty&&Object.keys)try{var t=Object.keys(e);return t.forEach(function(t){Object.defineProperty(n,t,{get:function(){return e[t]},set:function(n){return e[t]=n,n}})}),n}catch(r){l([r])}for(var i in e)f.call(e,i)&&(n[i]=e[i]);return n}function l(n){try{e.emit("internal-error",n)}catch(t){}}return e||(e=i),t.inPlace=u,t.flag=a,t}},{}]},{},["loader"]);</script><link rel="shortcut icon" href="/favicon.ico">
    <!-- Place favicon.ico and apple-touch-icon.png in the root directory -->
    <!-- build:css styles/vendor.css -->
    <!-- bower:css -->

    <link rel="stylesheet" href="/styles/vendor.css">
    <link href="/styles/orderformpage/skeuocard.css" rel="stylesheet">
    <link rel="stylesheet" href="/styles/orderformpage/main.css">
    <link href="/styles/orderformpage/custom-overwrites.css" rel="stylesheet">
    <link href="/styles/orderformpage/auth-modal.css" rel="stylesheet">

    <script src="/script/modernizr.js"></script>

    <style>
        #secret-code-modal-body {
            padding: 0px;
        /media/dreamadmin/DreamOval/Engineering/iwallet/web/paylivetest
        }
        #secret-code-modal-content {
            background-image: url("/images/patterns/iwallet-bg-sunset.jpg");
        }
        #secret-code-confirm {
            margin-bottom: 0em;
        }
        .blur {
            -webkit-filter: blur(8px);
            -moz-filter: blur(8px);
            -o-filter: blur(8px);
            -ms-filter: blur(8px);
            filter: blur(8px);
            opacity: 0.8;
        }

        #header a.go-back-link {
            font-weight: 700;
            padding: 18px 33px;
            margin-top: 8px;
            color: rgba(253,107,107,1);
            border: 1px solid rgba(253,107,107,1);
            background: rgba(253,107,107,0.1);
        }
        #header a.go-back-link:hover {
            background: rgba(253,107,107,1);
            color: #fff;
        }

    </style>

    <script>
        var secCode = [];
        var exServeCode = [];
        var paymentChannels = [{"name":"VISA","active":true,"id":1411180140074,"logourl":"images/orderformpage/logo-visa.png"},{"name":"MTN Mobile Money","active":true,"id":1411180140065,"logourl":"images/orderformpage/logo-mtn.png"},{"name":"AirtelTigo Money","active":true,"id":1411180140083,"logourl":"images/orderformpage/logo-airtel.png"},{"name":"Slydepay","active":true,"id":1411180141183,"logourl":"images/orderformpage/logo-slydepay.png"},{"name":"Tigo Cash","reason":"This payment option has been deactivated on Slydepay","active":false,"id":1495033411848,"logourl":"/images/orderformpage/logo-tigo.png"},{"name":"Vodafone Cash","active":true,"id":1495033422848,"logourl":"/images/orderformpage/logo-vodafone.png"}]

        var b = 1800000

    </script>

</head>

<body>
<!--[if lt IE 10]>
<p class="browsehappy">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
<![endif]-->




<div id="timeout-container" class="hide">
    <label id="timeout-label"></label>
</div>
<!-- password authentication -->
<div class="eternity-form modal fade auth-modal" id="auth-pword-modal">
    <a href="#" id="authorize-pword" class="hide"></a>
    <div class="modal-dialog">
        <div class="modal-content">
            <section>
                <form id="auth-pword-form">

                    <div class="modal-body">

                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>

                        <div class="textbox-wrap">
                            <label>Please enter your password to continue.</label>
                            <div class="input-group">
                                <span class="input-group-addon "><i class="fa fa-key icon-color"></i></span>
                                <input type="password" id="auth_user_pword" name="auth_user_pword" autofocus class="form-control" placeholder="Password" />
                                <button type="submit" id="auth-pword-button" class="btn ladda-button submit-btn" data-style="zoom-in">
                                    <span class="ladda-label"><i class="fa fa-hand-o-right"></i></span>
                                </button>
                            </div>
                        </div>

                    </div>
                </form>
            </section>
        </div>
    </div>
</div>

<!-- birthday authentication -->
<div class="eternity-form modal fade auth-modal" id="auth-bday-modal">
    <a href="#" id="authorize-bday" class="hide"></a>
    <div class="modal-dialog">
        <div class="modal-content">
            <section>
                <form id="auth-bday-form">
                    <div class="modal-header">
                        <p><i class="fa fa-info-circle"></i> Please choose your birth date to continue.</p>
                    </div>

                    <div class="modal-body">

                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>

                        <div class="textbox-wrap">
                            <label>Choose your birth date</label>
                            <div class="input-group">
                                <span class="input-group-addon "><i class="fa fa-calendar icon-color"></i></span>
                                <input type="text" autofocus id="auth_user_bday" name="auth_user_bday" readonly="readonly" class="form-control bday" placeholder="Click here..." />
                                <button type="submit" id="auth-bday-button" class="btn ladda-button submit-btn" data-style="zoom-in">
                                    <span class="ladda-label"><i class="fa fa-hand-o-right"></i></span>
                                </button>
                            </div>
                        </div>

                    </div>
                </form>
            </section>
        </div>
    </div>
</div>

<!-- secret code authentication -->
<div class="eternity-form modal fade auth-modal" id="auth-code-modal">
    <a href="#" id="authorize-code" class="hide"></a>
    <div class="modal-dialog">
        <div class="modal-content">
            <section>
                <form id="auth-code-form">
                    <div class="modal-header">
                        <p><i class="fa fa-info-circle"></i> Please enter your secret code to continue.</p>
                    </div>

                    <div class="modal-body">

                        <div class="forgot-content">
                            <div class="secret-code-container clearfix">

                                <!-- First Secret Code -->
                                <div id="auth-secret-code" class="auth-secret-code">

                                    <div class="sec-code">
                                        <div class="text-center labels">
                                            <div class="spinner">
                                                <div class="rect1"></div>
                                                <div class="rect2"></div>
                                                <div class="rect3"></div>
                                                <div class="rect4"></div>
                                                <div class="rect5"></div>
                                            </div>
                                        </div>
                                        <form id="auth-code-form">

                                            <div class="digits-wrap">
                                                <table class="digits-table" width="100%">
                                                    <tbody>
                                                    <tr>
                                                        <td><input type="text" id="txtCode1" value="" readonly="readonly" class="codeInput en-ready" style="width:90%" maxlength="1"></td>
                                                        <td><input type="text" id="txtCode2" value="" readonly="readonly" class="codeInput" style="width:90%;padding-left:5px;" maxlength="1"></td>
                                                        <td><input type="text" id="txtCode3" value="" readonly="readonly" class="codeInput" style="width:90%;padding-left:5px;" maxlength="1"></td>
                                                        <td><input type="text" id="txtCode4" value="" readonly="readonly" class="codeInput" style="width:90%;padding-left:5px;" maxlength="1"></td>
                                                        <td><input type="text" id="txtCode5" value="" readonly="readonly" class="codeInput" style="width:90%;padding-left:5px;" maxlength="1"></td>
                                                        <td><input type="text" id="txtCode6" value="" readonly="readonly" class="codeInput" style="width:90%;padding-left:5px;" maxlength="1"></td>
                                                    </tr>
                                                    </tbody>
                                                </table>
                                            </div>

                                            <!-- keypad -->
                                            <div class="wrap">
                                                <table class="normal-scode keypad-table">
                                                    <tbody>
                                                    <tr>
                                                        <td>
                                                            <input type="button" class="btn btn-link keypad-btn digit" value="1" />
                                                        </td>

                                                        <td>
                                                            <input type="button" class="btn btn-link keypad-btn digit" value="2" />
                                                        </td>

                                                        <td>
                                                            <input type="button" class="btn btn-link keypad-btn digit" value="3" />
                                                        </td>
                                                    </tr>

                                                    <tr>
                                                        <td>
                                                            <input type="button" class="btn btn-link keypad-btn digit" value="4" />
                                                        </td>

                                                        <td>
                                                            <input type="button" class="btn btn-link keypad-btn digit" value="5" />
                                                        </td>

                                                        <td>
                                                            <input type="button" class="btn btn-link keypad-btn digit" value="6" />
                                                        </td>
                                                    </tr>

                                                    <tr>
                                                        <td>
                                                            <input type="button" class="btn btn-link keypad-btn digit" value="7" />
                                                        </td>

                                                        <td>
                                                            <input type="button" class="btn btn-link keypad-btn digit" value="8" />
                                                        </td>

                                                        <td>
                                                            <input type="button" class="btn btn-link keypad-btn digit" value="9" />
                                                        </td>
                                                    </tr>

                                                    <tr>
                                                        <td>
                                                            <button type="button" class="btn btn-link keypad-btn btn-clear btn-aux">
                                                                <span><i class="fa fa-ban"></i></span>
                                                            </button>
                                                        </td>

                                                        <td>
                                                            <input type="button" class="btn btn-link keypad-btn digit" value="0" />
                                                        </td>

                                                        <td>
                                                            <button type="button" class="btn btn-link keypad-btn btn-bckspc btn-aux">
                                                                <span><i class="fa fa-long-arrow-left"></i></span>
                                                            </button>
                                                        </td>
                                                    </tr>

                                                    </tbody>
                                                </table>

                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="text-center">
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        </div>

                    </div>
                </form>
            </section>
        </div>
    </div>
</div>

<div class="eternity-form modal fade auth-modal" id="redirect-modal">
    <div class="modal-dialog">
        <div class="modal-content">

            <div class="modal-body">

                <h1 class="title">Redirecting in <span id="redirect-timer"></span></h1>

                <p class="msg">Please wait while we take you back to the merchant site. <i class="fa fa-smile-o"></i></p>

            </div>
        </div>
    </div>
</div>


<div id="ordered-items-modal" class="modal fade">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <div class="modal-title">
                            <span class="order-cart">
                                <i class="fa fa-shopping-cart"></i>
                                <span class="badge order-items-number no-of-orderitems"></span>
                            </span> Ordered Items
                </div>
            </div>

            <div class="modal-body">

                <div id="ordered-items-list">
                    <div class="row">
                        <div class="all-items" id="order-item-list2">

                        </div>
                    </div>
                </div>

                <div class="scroll-actions text-center">
                    <a href="#" class="scroll-down">
                        <small><i class="fa fa-chevron-down"></i> Scroll to bottom</small>
                    </a>

                    <a href="#" class="scroll-up">
                        <small><i class="fa fa-chevron-up"></i> Scroll to top</small>
                    </a>
                </div>

            </div>

            <div class="modal-footer">
                <div class="row">
                    <div class="col-md-6">
                        <div id="summary-list" class="text-left">
                            <div class="row">
                                <div class="summary-item col-md-6 col-xs-6">
                                    Subtotal
                                </div>
                                <div class="summary-item text-right col-md-6 col-xs-6">
                                    GHS <span id="order-subtotal"></span>
                                </div>

                                <div class="summary-item col-md-6 col-xs-6">
                                    TAX/VAT
                                </div>
                                <div class="summary-item text-right col-md-6 col-xs-6">
                                    GHS <span id="order-taxamount"></span>
                                </div>

                                <div class="summary-item col-md-6 col-xs-6">
                                    Delivery/Shipping
                                </div>
                                <div class="summary-item text-right col-md-6 col-xs-6">
                                    GHS <span id="order-shipping"></span>
                                </div>

                                <div class="col-md-12 col-xs-12 total">
                                    <strong>TOTAL</strong>
                                    <strong class="total-amt">GHS <span id="order-total"></span></strong>
                                </div>

                            </div>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <button type="button" data-dismiss="modal" class="btn btn-lg btn-block btn-success">OK</button>
                    </div>
                </div>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div>

<div id="mtn-modal" class="modal fade">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <div class="modal-title">
                            <span class="modal-header-icon">
                                <img src="/images/orderformpage/logo-mtn.png" width="34" height="34"/>
                            </span> MTN Mobile Money
                </div>
            </div>

            <form id="mtn-step1">
                <div class="modal-body">

                    <div id="mtn-message-info" class="form-info alert alert-info">
                        <i class="fa fa-info-circle"></i> You need to have at least<strong> GHS </strong> <strong class="total-amount"></strong> in your mobile money wallet






                    </div>
                    <div id="mtn-message-error" class="form-error hide alert alert-danger">
                        <i class="fa fa-info-circle"></i>
                    </div>

                    <div class="form-group">
                        <label for="mtnName">Name</label>
                        <input type="text" class="form-control" id="mtnName" name="mtnName" placeholder="">
                    </div>


                    <div class="row">
                        <div class="col-sm-7">
                            <div class="form-group">
                                <label for="mtnNumber">MTN Mobile Number <span class="field-required">(required)</span></label>
                                <input type="tel" class="form-control" id="mtnNumber" name="mtnNumber" placeholder="">
                            </div>
                        </div>

                        <div class="col-sm-5">
                            <div class="form-group">
                                <label for="billAmount">Amount</label>
                                <input type="text" class="form-control billAmount total-amount" id="billAmount" readonly="readonly" value="GHS ">
                            </div>
                        </div>
                    </div>
                </div>

                <div class="modal-footer">
                    <button type="button" data-dismiss="modal" class="btn btn-default">Cancel</button>
                    <button type="submit" data-style="expand-left" class="btn btn-success ladda-button">
                                <span class="ladda-label">
                                    Next <i class="fa fa-chevron-right"></i>
                                </span>
                    </button>
                </div>
            </form>

            <div id="mtn-step2" >
                <div class="modal-body">
                    <div id="mtn-info" class="form-info alert alert-info">


                        <i class="fa fa-info-circle"></i> To complete your payment:

                            <div class="alert alert-info">
                                <p align="center">Please check your phone for a payment</p>
                                <p align="center">confirmation prompt from MTN Mobile Money.</p>
                                <p align="center">You can also authorize the transaction in your</p>
                                <p align="center">MoMo approvals.</p>
                                <p align="center" style="color:red;">NB. Prompt will not show if you have an insufficent</p>
                                <p align="center" style="color:red;">balance</p>
                            </div>










                    </div>

                    <div class="text-center">
















                        <p class="processing-msg">
                            <img src="/images/orderformpage/Preloader_8.gif"/><br>
                            <!-- processing... -->
                        </p>

                    </div>
                </div>

            </div>

            <div id="mtn-step-linked" >
                <div class="modal-body">

                    <div class="text-center">
                        <div class="alert alert-info">
                            Your transaction is being processed. Customers will receive an SMS as confirmation for
                            successful transaction
                            <br/>

                        </div>

                        <p class="processing-msg">
                            <img src="/images/orderformpage/Preloader_8.gif"/><br>
                            <!-- processing... -->
                        </p>

                    </div>
                </div>
            </div>

            <div id="mtn-step3" >
                <div class="modal-body">

                    <div class="text-center">

                        <p class="done-msg">
                            <i class="fa fa-smile-o"></i> <br>
                            Purchase completed!
                        </p>

                    </div>
                </div>

                <div class="modal-footer">
                    <button type="button" data-dismiss="modal" data-style="expand-left" class="btn btn-success ladda-bootstrap">
                                <span class="ladda-label">
                                    OK <i class="fa fa-check"></i>
                                </span>
                    </button>
                </div>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div>

<div id="airtel-modal" class="modal fade">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <div class="modal-title">
                            <span class="modal-header-icon">

                                <img src="/images/orderformpage/logo-airtel.png" width="34" height="34"/>
                            </span> AirtelTigo Money
                </div>
            </div>

            <form id="airtel-step1" >
                <div class="modal-body">

                    <div id="airtel-message-info" class="form-info alert alert-info">
                        <i class="fa fa-info-circle"></i> You need to have at least<strong style="font-weight: bold"> GHS </strong> <strong class="total-amount" style="font-weight: bold"> </strong> in your mobile money wallet
                    </div>

                    <div id="airtel-message-error" class="form-error hide alert alert-danger">
                        <i class="fa fa-info-circle"></i>
                    </div>

                    <div class="form-group">
                        <label for="airtelName">Name</label>
                        <input type="text" class="form-control" id="airtelName" name="airtelName" placeholder="">
                    </div>


                    <div class="row">
                        <div class="col-sm-7">
                            <div class="form-group">
                                <label for="airtelNumber">Airtel Mobile Number <span class="field-required">(required)</span></label>
                                <input type="tel" class="form-control" id="airtelNumber" name="airtelNumber" placeholder="">
                            </div>
                        </div>

                        <div class="col-sm-5">
                            <div class="form-group">
                                <label for="billAmount">Amount</label>
                                <input type="text" class="form-control billAmount total-amount" id="billAmount" readonly="readonly" value="">
                            </div>
                        </div>
                    </div>
                </div>

                <div class="modal-footer">
                    <button type="button" data-dismiss="modal" class="btn btn-default">Cancel</button>
                    <button type="submit" data-style="expand-left" class="btn btn-success btn-next ladda-bootstrap">
                                <span class="ladda-label">
                                    Next <i class="fa fa-chevron-right"></i>
                                </span>
                    </button>
                </div>
            </form>


            <div id="airtel-step2" >
                <div class="modal-body">

                    <div class="text-center">
                        <p class="alert alert-info">
                            Please check your phone for a prompt from Airtel
                            Click the done button when the payment is complete on your phone
                        </p>

                        <p class="processing-msg">
                            <img src="/images/orderformpage/Preloader_8.gif"/><br>
                            <!-- processing... -->
                        </p>

                    </div>
                </div>

                <div class="modal-footer">
                    <button type="button" data-style="expand-left" class="btn btn-success ladda-bootstrap">
                                <span class="ladda-label">
                                    Done
                                </span>
                    </button>
                </div>
            </div>

            <div id="airtel-step3" >
                <div class="modal-body">

                    <div class="text-center">

                        <p class="done-msg">
                            <i class="fa fa-smile-o"></i> <br>
                            Purchase completed!
                        </p>

                    </div>
                </div>

                <div class="modal-footer">
                    <button type="button" data-dismiss="modal" data-style="expand-left" class="btn btn-success ladda-bootstrap">
                                <span class="ladda-label">
                                    OK <i class="fa fa-check"></i>
                                </span>
                    </button>
                </div>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div>

<div id="tigo-modal" class="modal fade">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <div class="modal-title">
                            <span class="modal-header-icon">

                                <img src="/images/orderformpage/icon-tigo.png" width="34" height="34"/>
                            </span> Tigo Cash
                </div>
            </div>

            <form id="tigo-step1" >
                <div class="modal-body">

                    <div id="tigo-message-info" class="form-info alert alert-info">
                        <i class="fa fa-info-circle"></i> You need to have at least<strong style="font-weight: bold"> GHS </strong> <strong class="total-amount" style="font-weight: bold"> </strong> in your mobile money wallet
                    </div>

                    <div id="tigo-message-error" class="form-error hide alert alert-danger">
                        <i class="fa fa-info-circle"></i>
                    </div>

                    <div class="form-group">
                        <label for="tigoName">Name</label>
                        <input type="text" class="form-control" id="tigoName" name="tigoName" placeholder="">
                    </div>


                    <div class="row">
                        <div class="col-sm-7">
                            <div class="form-group">
                                <label for="tigoNumber">Tigo Mobile Number <span class="field-required">(required)</span></label>
                                <input type="tel" class="form-control" id="tigoNumber" name="tigoNumber" placeholder="">
                            </div>
                        </div>

                        <div class="col-sm-5">
                            <div class="form-group">
                                <label for="tigoBillAmount">Amount</label>
                                <input type="text" class="form-control billAmount total-amount" id="tigoBillAmount" readonly="readonly" value="">
                            </div>
                        </div>
                    </div>
                </div>

                <div class="modal-footer">
                    <button type="button" data-dismiss="modal" class="btn btn-default">Cancel</button>
                    <button type="submit" data-style="expand-left" class="btn btn-success btn-next ladda-bootstrap">
                                <span class="ladda-label">
                                    Next <i class="fa fa-chevron-right"></i>
                                </span>
                    </button>
                </div>
            </form>


            <div id="tigo-step2" >
                <div class="modal-body">

                    <div class="text-center">
                        <p class="alert alert-info">
                            Dial *501*5# to complete the payment. Click the done button when you complete the payment on your phone
                        </p>

                        <p class="processing-msg">
                            <img src="/images/orderformpage/Preloader_8.gif"/><br>
                            <!-- processing... -->
                        </p>

                    </div>
                </div>

                <div class="modal-footer">
                    <button type="button" data-style="expand-left" class="btn btn-success ladda-bootstrap">
                                <span class="ladda-label">
                                    Done
                                </span>
                    </button>
                </div>
            </div>

            <div id="tigo-step3" >
                <div class="modal-body">

                    <div class="text-center">

                        <p class="done-msg">
                            <i class="fa fa-smile-o"></i> <br>
                            Purchase completed!
                        </p>

                    </div>
                </div>

                <div class="modal-footer">
                    <button type="button" data-dismiss="modal" data-style="expand-left" class="btn btn-success ladda-bootstrap">
                                <span class="ladda-label">
                                    OK <i class="fa fa-check"></i>
                                </span>
                    </button>
                </div>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div>


<div id="vodafone-modal" class="modal fade">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <div class="modal-title">
                            <span class="modal-header-icon">

                                <img src="/images/orderformpage/icon-vodafone.png" width="34" height="34"/>
                            </span> Vodafone Cash
                </div>
            </div>

            <form id="vodafone-step1" >
                <div class="modal-body">

                    <div id="vodafone-message-info" class="form-info alert alert-info">
                        <i class="fa fa-info-circle"></i> Dial<strong style="font-weight: bold"> *110#, select the option "Make Payments" and then "Generate Voucher" </strong> for your Vodafone token. Your token will expire after 2 minutes.
                    </div>

                    <div id="vodafone-message-error" class="form-error hide alert alert-danger">
                        <i class="fa fa-info-circle"></i>
                    </div>

                    <div class="row">
                        <div class="col-sm-7">
                            <div class="form-group">
                                <label for="vodafoneName">Name</label>
                                <input type="text" class="form-control" id="vodafoneName" name="tigoName" placeholder="">
                            </div>
                        </div>

                        <div class="col-sm-5">
                            <div class="form-group">
                                <label for="vodafoneToken">Vodafone Token <span class="field-required">(required)</span></label>
                                <input type="text" class="form-control" id="vodafoneToken" name="vodafoneToken" placeholder="">
                            </div>
                        </div>
                    </div>




                    <div class="row">
                        <div class="col-sm-7">
                            <div class="form-group">
                                <label for="vodafoneNumber">Vodafone Mobile Number <span class="field-required">(required)</span></label>
                                <input type="tel" class="form-control" id="vodafoneNumber" name="vodafoneNumber" placeholder="">
                            </div>
                        </div>

                        <div class="col-sm-5">
                            <div class="form-group">
                                <label for="vodafoneBillAmount">Amount</label>
                                <input type="text" class="form-control billAmount total-amount" id="vodafoneBillAmount" readonly="readonly" value="">
                            </div>
                        </div>
                    </div>
                </div>

                <div class="modal-footer">
                    <button type="button" data-dismiss="modal" class="btn btn-default">Cancel</button>
                    <button type="submit" data-style="expand-left" class="btn btn-success btn-next ladda-bootstrap">
                                <span class="ladda-label">
                                    Next <i class="fa fa-chevron-right"></i>
                                </span>
                    </button>
                </div>
            </form>


            <div id="vodafone-step2" >
                <div class="modal-body">

                    <div class="text-center">
                        <p class="alert alert-info">
                            Please wait while we complete your payment.
                        </p>

                        <p class="processing-msg">
                            <img src="/images/orderformpage/Preloader_8.gif"/><br>
                            <!-- processing... -->
                        </p>

                    </div>
                </div>

                <div class="modal-footer">
                </div>
            </div>

            <div id="vodafone-step3" >
                <div class="modal-body">

                    <div class="text-center">

                        <p class="done-msg">
                            <i class="fa fa-smile-o"></i> <br>
                            Purchase completed!
                        </p>

                    </div>
                </div>

                <div class="modal-footer">
                    <button type="button" data-dismiss="modal" data-style="expand-left" class="btn btn-success ladda-bootstrap">
                                <span class="ladda-label">
                                    OK <i class="fa fa-check"></i>
                                </span>
                    </button>
                </div>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div>


<div id="visa-modal" class="modal fade">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <div class="modal-title">
                            <span class="modal-header-icon">
                                <img src="/images/orderformpage/logo-visamastercard.png" width="34" height="34">
                            </span> Credit/Debit Card
                </div>
            </div>

            <form id="visa-step1" >
                <div class="modal-body">

                    <div class="visa-form-info"></div>

                    <fieldset>
                        <legend>Enter card details</legend>

                        <div class="row visible-xs" id="mobile-card-form">
                            <div class="col-sm-12">
                                <div class="form-group">
                                    <label for="card_num">Card Number</label>
                                    <input type="text" class="form-control" id="card_num" name="card_num" placeholder="1234 5678 9123 4567" required>
                                </div>
                            </div>

                            <div class="col-xs-6">
                                <div class="form-group">
                                    <label for="card_exp_month">Expiry Month</label>
                                    <input type="text" required class="form-control" id="card_exp_month" name="card_exp_month" placeholder="e.g. 09" maxlength="2">
                                </div>
                            </div>

                            <div class="col-xs-6">
                                <div class="form-group">
                                    <label for="card_exp_year">Expiry Year</label>
                                    <input type="text" required class="form-control" id="card_exp_year" name="card_exp_year" placeholder="e.g. 16" maxlength="2">
                                </div>
                            </div>

                            <div class="col-xs-8">
                                <div class="form-group">
                                    <label for="card_name">Card Name</label>
                                    <input type="text" required class="form-control" id="card_name" name="card_name" placeholder="Name on card">
                                </div>
                            </div>



                            <div class="col-xs-4">
                                <div class="form-group">
                                    <label for="card_cvv">CVV</label>
                                    <input type="text" required class="form-control" id="card_cvv" name="card_cvv" placeholder="123">
                                </div>
                            </div>
                        </div>

                        <div class="card-container hidden-xs" id="skeuocard">
                            <p class="no-support-warning">
                                Either you have Javascript disabled, or you're using an unsupported browser!
                            </p>


                            <label for="cc_type">Card Type</label>
                            <select name="cc_type">
                                <option value="">...</option>
                                <option value="visa">Visa</option>
                                <option value="discover">Discover</option>
                                <option value="mastercard">MasterCard</option>
                                <option value="maestro">Maestro</option>
                                <option value="jcb">JCB</option>
                                <option value="unionpay">China UnionPay</option>
                                <option value="amex">American Express</option>
                                <option value="dinersclubintl">Diners Club</option>
                            </select>

                            <label for="cc_number">Card Number</label>
                            <input type="text" name="cc_number" id="cc_number" placeholder="XXXX XXXX XXXX XXXX" maxlength="19" size="19">

                            <label for="cc_exp_month">Expiration Month</label>
                            <input type="text" name="cc_exp_month" id="cc_exp_month" placeholder="00">

                            <label for="cc_exp_year">Expiration Year</label>
                            <input type="text" name="cc_exp_year" id="cc_exp_year" placeholder="00">

                            <label for="cc_name">Cardholder's Name</label>
                            <input type="text" name="cc_name" id="cc_name" placeholder="John Doe">

                            <label for="cc_cvc">Card Validation Code</label>
                            <input type="text" name="cc_cvc" id="cc_cvc" placeholder="123" maxlength="3" size="3">
                        </div>
                    </fieldset>

                    <fieldset>
                        <legend>Contact details</legend>
                        <div class="row">
                            <div class="col-sm-7">
                                <div class="form-group">
                                    <label for="visaEmail">Email address</label>
                                    <input type="email" class="form-control" id="visaEmail" name="visaEmail" placeholder="">
                                </div>
                            </div>

                            <div class="col-sm-5">
                                <div class="form-group">
                                    <label for="visaMobile">Mobile #</label>
                                    <input type="tel" class="form-control visaMobile" id="visaMobile" name="visaMobile" >
                                </div>
                            </div>
                        </div>
                    </fieldset>


                </div>

                <div class="modal-footer">
                    <button id="cancel-visa-modal" style="display: inline" type="button" data-dismiss="modal" class="btn btn-default">Cancel</button>
                    <a id="cancel-url-modal" style="display: none" href="/paylive/orderform/cancel?iwalletOrderId=" class="btn btn-danger pull-left" type="button">
                        <i class="fa fa-times"></i> Cancel Order
                    </a>
                    <button type="submit" id="visa-next" class="btn btn-success btn-next ladda-button" data-style="expand-left">
                                <span class="ladda-label">
                                    Next <i class="fa fa-chevron-right"></i>
                                </span>
                    </button>
                </div>
            </form>

            <!-- step 2 -->
            <div id="visa-step2" >
                <iframe width="100%" scrolling="no" src="" frameborder="0" seamless="seamless"></iframe>
            </div>

        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<div id="visa-modal-link" class="modal fade">
    <div class="modal-dialog">
        <div class="modal-content" style="height: 500px; width:800px">
            <div class="modal-header">
                <div class="modal-title">
                            <span class="modal-header-icon">
                                <img src="/images/orderformpage/logo-visamastercard.png" width="34" height="34">
                            </span> Credit/Debit Card
                </div>
            </div>
            <!-- step 2 -->
            <div id="visa-step-link-card" style="height: inherit">
                <iframe name="card_iframe" width="100%" scrolling="no" src="" frameborder="0" seamless="seamless" style="height: inherit"></iframe>
            </div>

        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->


<div class="eternity-form modal fade" id="cvv-modal">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <div class="modal-title">
                            <span class="modal-header-icon">
                                <img src="/images/orderformpage/logo-visamastercard.png" width="34" height="34">
                            </span> Credit/Debit Card
                </div>
            </div>

            <form id="cvv-form" >
                <div class="modal-body">

                    <div class="form-group">
                        <label for="cvvVal">Card Validation Code</label>
                        <input type="password" class="form-control" name="cvvVal" id="cvvVal" placeholder="123" minlength="3" maxlength="3" size="3">
                    </div>

                </div>

                <div class="modal-footer">
                    <button type="button" data-dismiss="modal" class="btn btn-default" style="width: 100;border: 2px white;padding: 10px 10px; font-weight:bold; font-size: 14">Cancel</button>

                    <button class="btn btn-white pay-btn ladda-button" id="cvv-button" data-style="zoom-in" data-spinner-color="#67b16f">
                        <span class="ladda-label">PAY</span>
                    </button>

                </div>
            </form>

        </div>
    </div>
</div>

<div id="cvv-div" style="display: none">

</div>

<div class="container main-page">

    <div class="row">
        <div class="col-md-12">
            <header id="header">

                <a href="#" id="logo"><img src="/images/slidepay.png"/></a>

                <a id="cancel-url" href="/paylive/orderform/cancel?iwalletOrderId=" class="pull-left go-back-link">

                    <i class="fa fa-times"></i> Cancel Order
                </a>

                <div class="pull-right dropdown mobile-nav">
                    <button type="button" data-toggle="dropdown" class="btn btn-primary" id="mobile-nav-btn">
                        <i class="fa fa-bars"></i>
                    </button>
                    <ul class="dropdown-menu" id="mobile-nav-dropdown" role="menu" aria-labelledby="mobile-nav-btn">
                        <li>
                            <a href="#">
                                <i class="fa fa-times"></i> Cancel Order
                            </a>
                        </li>
                    </ul>
                </div>
            </header>
        </div>
    </div>

</div>

<div class="container main-page">
    <div class="row">

        <div id="order-form-container" class="col-md-8 col-lg-7 col-lg-offset-1">
            <div id="pay-summary">
                <div class="header">
                    <span class="merchant-name"></span>
                    <span class="order-cart pull-right">
                                <a href="#" class="order-details">
                                    <i class="fa fa-shopping-cart"></i>
                                </a>
                                <span class="badge order-items-number no-of-orderitems"></span>
                            </span>
                </div>

                <div class="divider"></div>

                <div class="bill">
                    <div class="no-margin">
                        <span class="badge">Your bill</span>
                    </div>
                    <div class="bill-amount">
                        <span class="currency">GHS</span> <span class="number total-amount"></span><span class="superscript"></span>
                    </div>
                </div>
            </div>

            <div id="iwallet-login">
                <div class="login-container ">

                    <h5 class="title pay">PAY WITH Slydepay</h5>
                    <form id="login-form" class="" role="form">
                        <div class="row">
                            <div class="col-sm-5">
                                <div class="form-group">
                                    <label class="sr-only" for="userEmail">Email address</label>
                                    <input type="text" class="form-control" id="userEmail" name="userEmail" placeholder="Enter email or phone number" disabled>
                                </div>
                            </div>
                            <div class="col-sm-5">
                                <div class="form-group">
                                    <label class="sr-only" for="userPassword">Password</label>
                                    <input type="password" class="form-control" id="userPassword" name="userPassword" placeholder="Password" disabled>
                                </div>
                            </div>
                            <div class="col-sm-2">
                                <button type="submit" id="login-btn" class="btn-submit btn btn-default btn-block ladda-button" data-style="zoom-in" data-spinner-color="#67b16f" disabled>
                                            <span class="ladda-label">
                                                PAY
                                            </span>
                                </button>
                            </div>
                        </div>
                    </form>

                    <div id="logged-in">
                        <div id="logged-in-wrapper" class="row">
                            <div class="col-lg-6 col-sm-6">
                                <div id="user-details">
                                    <div id="user-name">
                                                <span class="user-icon">
                                                    <i class="fa fa-user"></i>
                                                </span>
                                        <span id="customer-name"></span>

                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6 col-sm-6">
                                <div id="accounts">
                                    <select id="user_accounts" class="cd-select">
                                        <option value="" selected>Choose an account</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div id="other-pay-options" class="clearfix">
                <h5 class="title">or Pay with:</h5>
                <div class="options-container">

                    <div class="row" id="pay-options-row">
                        <div class="col-xs-3 col-sm-3 col-md-3 text-center pay-option-container pay-opt disabled" id="airtel-money-opt">
                            <a href="#" id="pay-with-airtel" class="pay-option">
                                <img src="/images/orderformpage/logo-airtel.png" class="pay-option-img"/>
                                <div class="option-name">Airtel Money</div>
                            </a>
                        </div>

                        <div class="col-xs-3 col-sm-3 col-md-3 text-center pay-option-container pay-opt disabled" id="mtn-money-opt">
                            <a href="#" id="pay-with-mtn" class="pay-option">
                                <img src="/images/orderformpage/logo-mtn.png" class="pay-option-img"/>
                                <div class="option-name">MTN Mobile Money</div>
                            </a>
                        </div>

                        <div class="col-xs-3 col-sm-3 col-md-3 text-center pay-option-container pay-opt disabled" id="visa-opt">
                            <a href="#" id="pay-with-visa" class="pay-option">
                                <img src="/images/orderformpage/logo-visamastercard.png" class="pay-option-img"/>
                                <div class="option-name">Credit/Debit Card</div>
                            </a>
                        </div>

                        <div class="col-xs-3 col-sm-3 col-md-3 text-center pay-option-container pay-opt disabled" id="tigo-cash-opt">
                            <a href="#" id="pay-with-tigo" class="pay-option">
                                <img src="/images/orderformpage/icon-tigo.png" class="pay-option-img"/>
                                <div class="option-name">Tigo Cash</div>
                            </a>
                        </div>
                        <div class="col-xs-3 col-sm-3 col-md-3 text-center pay-option-container pay-opt disabled" id="vodafone-cash-opt">
                            <a href="#" id="pay-with-vodafone" class="pay-option">
                                <img src="/images/orderformpage/icon-vodafone.png" class="pay-option-img"/>
                                <div class="option-name">Vodafone Cash</div>
                            </a>
                        </div>

                    </div>
                </div>
            </div>

            <div id="iwallet-pay-login" class="clearfix">
                <button id="logout-btn">
                    <i class="fa fa-times-circle" title="Logout"></i> Logout
                </button>
                <!-- no account selected -->
                <div class="no-account acct-option">
                            <span class="arrow text-right floating">
                                <i class="fa fa-arrow-up"></i>
                            </span>
                    <div id="select-account-msg" class="text-center">
                        Choose an account to pay with...
                    </div>
                </div>

                <div id="account-selected" class="acct-option text-center">
                    <div class="confirm-msg">
                        Pay with this account? Your balance for this account is:
                    </div>
                    <span id="acct-balance" class="balance">
                                GHS
                            </span>

                    <button class="btn btn-white pay-btn ladda-button payWithAccountBtn" id="payWithAccountBtn" data-style="zoom-in" data-spinner-color="#67b16f">
                        <span class="ladda-label">PAY</span>
                    </button>
                </div>

                <div id="account-selected-no-balance" class="acct-option text-center">
                    <div class="confirm-msg">
                        Pay with this account?
                    </div>

                    <button class="btn btn-white pay-btn ladda-button payWithAccountBtn" id="payWithAccountBtn-no-balance" data-style="zoom-in" data-spinner-color="#67b16f">
                        <span class="ladda-label">PAY</span>
                    </button>
                </div>

                <div id="account-selected-insufficient-bal" class="no-account acct-option" style="display: none">
                            <span class="arrow text-right">
                                <i class="fa fa-arrow-up"></i>
                            </span>
                    <div id="account-selected-insufficient-bal-msg" class="text-center" >
                        This account has insufficient balance. Please select another account...
                    </div>
                </div>

                <div id="loader" class="loader">
                    <ul class="bokeh">
                        <li></li>
                        <li></li>
                        <li></li>
                        <li></li>
                    </ul>

                    Please wait...
                </div>
            </div>

        </div>

        <div id="iphone-container" class="col-md-4" style="display: none;">

            <div class="iphone col-sm-2">

                <div class="qrcode-container">
                    <img id="paylive-qrcode" src="/images/orderformpage/qrcode.png" class="qrcode"/>
                </div>
                <div class="paycode">
                    PAY CODE: <strong id="paycode">859684</strong>
                </div>

                <button type="button" id="mobile-payment-complete" class="btn btn-default btn-block ladda-button" data-style="zoom-in" data-spinner-color="#67b16f" style="display: inline-block;
width: 50%">
                                            <span class="ladda-label">
                                                DONE
                                            </span>
                </button>
                <p>Scan to pay with Slydepay Mobile</p>
                <p>Click the <b>Done</b> button </p>
                <p>when payment is complete</p>

            </div>

        </div>

    </div>
</div>


<script src="/script/vendor.js"></script>
<script src="/script/addfunds/jquery.inputmask.js"></script>
<script src="/script/orderformpage/main.js"></script>
<script src="/script/orderformpage/action-auth.js"></script>`

<script type="text/javascript">

    /*$(document).ready(function() {
     OrderFormPage.init();
     });*/
    var loginUrl = "/paylive/orderform/login";
    var logoutUrl = "/auth/logout";
    var airtelPayUrl = "/paylive/orderform/pay/airtel";
    var tigoPayUrl = "/paylive/orderform/pay/mobilemoney";
    var vodafonePayUrl = "/paylive/orderform/pay/mobilemoney";
    var mtnPayUrl = "/paylive/orderform/pay/mtn";
    var secretCodeLoginUrl = "/auth/evaluatechallenge/map";
    var secretCodeValidateUrl = "/auth/validate/secretcode";
    var checkPaymentStatusUrl = "/paylive/orderform/checkstatus";
    var securityAnswerValidateUrl = "/user/validate/secretanswer";
    var birthdayValidateUrl = "/user/validate/birthday";
    var createVisaPaymentUrl = "/paylive/orderform/create/pay/visa/new";
    var institutionTransId = "";
    var loginResult = "";
    var accounts = "";
    var selectedAccountValue = "";
    var order = {"orderType":"MERCHANT","shippingCost":0,"comment2":"","orderId":"1575677484904","hasBillItems":false,"apiConfigDisplayName":"XPARK","extraParameters":"provider=MTN_MONEY&","discountAmount":0,"apiConfigNickName":"Xmall","orderItems":[{"unitPrice":54,"quantity":1,"itemCode":"1000110337","subTotal":54}],"realTotal":54,"version":4,"merchantKey":"1542142675905","merchantInvoiceNumber":"1000110337","total":54,"dateCreated":"2020-02-25 21:21:14.0","paymentCode":"kwz4y6","discounts":[],"subtotal":54,"orderItemNames":",null,null,null","lastModified":"Tue Feb 25 21:21:15 UTC 2020","id":"ff619571-cf86-49b2-84ac-6a23825691a1","taxAmount":0,"payToken":"43fb2055-568f-4525-8f0b-fb940c360bb7"};
    var orderItems = {"orderType":"MERCHANT","shippingCost":0,"comment2":"","orderId":"1575677484904","hasBillItems":false,"apiConfigDisplayName":"XPARK","extraParameters":"provider=MTN_MONEY&","discountAmount":0,"apiConfigNickName":"Xmall","orderItems":[{"unitPrice":54,"quantity":1,"itemCode":"1000110337","subTotal":54}],"realTotal":54,"version":4,"merchantKey":"1542142675905","merchantInvoiceNumber":"1000110337","total":54,"dateCreated":"2020-02-25 21:21:14.0","paymentCode":"kwz4y6","discounts":[],"subtotal":54,"orderItemNames":",null,null,null","lastModified":"Tue Feb 25 21:21:15 UTC 2020","id":"ff619571-cf86-49b2-84ac-6a23825691a1","taxAmount":0,"payToken":"43fb2055-568f-4525-8f0b-fb940c360bb7"}.orderItems
    var merchantDetails = {"displayName":"XPARK","callbackURL":"https://gh.xpark.com/slydepay/index/callback","merchantKey":"1542142675905"}
    var merchantName = merchantDetails.displayName;
    var amount = order.total;
    var paycode = order.paymentCode;
    var secretCodeMap = "";
    exServeCode = [];
    var makePaymentAuth = "";
    var securityQuestion = "";
    var iframeUrl = '';
    var authCode = "";
    var emailOrMobile = "";
    var secretCodeValue = "";
    var cardProcessingUrl = "https://app.slydepay.com/cards/processor";


    $(document).ready(function() {
        $('.merchant-name').html(merchantName);
        $('.no-of-orderitems').html(orderItems.length);
        $('.total-amount').html(amount);
        $('.total-amount').val("GHS " + amount);
        $('#order-subtotal').html(order.subtotal);
        $('#order-taxamount').html(order.taxAmount);
        $('#order-shipping').html(order.shippingCost);
        $('#order-total').html(amount);
        $('#total-amount').html(amount);
        $('#paycode').html(paycode);
        ActionAuth.init();
        var img = document.getElementById('paylive-qrcode');
        img.src = 'data:image/jpeg;base64,' + "iVBORw0KGgoAAAANSUhEUgAAAH0AAAB9CAIAAAAA4vtyAAACA0lEQVR42u3bW27EIBAEQN//0skNVjY9A9hUf0bBa4qIx4S9/mRFLgTcuQt37sKdu3DnLty5C3fu3IU7d+HOXZa4X1nuPPnHZ/345TtvOKEX3LlzL3QPW1VRVo1xX9+5c+eeuz+aT8O1ZGxE1/aCO3fuq9zLW409hzt37ifM73ln7r8Gd+7cX+peNVrh9nFJL7hz575z/X2Tnxz3fw/u3N/gXp5w/xeW1WZ3ljt37tXz+6NWVQX0sFXHMZU7d+4T3McKZBNq9I/e+TX7d+7cv+Ieeo0NSV9xvHVa586d+4QBqFpLwip5+MAt6mLcuR/g/mim7qvRz7watem6yp37Ae5VX6vo2/+Fw7Z7nYA79wPcH71f1Y3q8qm/7w+CO3fuq+b3sIgWDsmE5Yo7d+6r3PvuE/Rdyuw4uHLnzn3MPbzANPZZVdP65J0ld+7cq+pQM2fzCfvIveZ37tyPdK+qU48tBmPDxp0797e79039fd82aT2mcufOfUlau1dyNt7rvMqd+0nu5Xcfw71d3/2GTfeR3Lmf5N7Xqup0WlVb586d+8719/DkGS4zH68TcOfOPdi3PXpyeHCtelXu3Lm/1D2czcNenLKP5M79u/WZquJXuCp84T4Bd+7fdS+vvy+pks/h5s6du0wLd+7chTt34c5duHMX7tyFO3fuwp27cOcuSf4BBTYkYtY7HgQAAAAASUVORK5CYII=" + '';

        var merchantKey = merchantDetails.merchantKey

        if (merchantKey != "") {
            $('#userEmail')[0].disabled = false
            $('#userPassword')[0].disabled = false
            $('#login-btn')[0].disabled = false
            $('#iphone-container')[0].style.display = ""
        }

        var _href = $("#cancel-url").attr("href");
        $("#cancel-url").attr("href", _href + order.orderId);
        var _href2 = $("#cancel-url-modal").attr("href");
        $("#cancel-url-modal").attr("href", _href2 + order.orderId);

        var appendOrderItemsString = "";
        if( orderItems != null) {
            for(i = 0; i < orderItems.length; i++) {
                var orderItem = orderItems[i];
                appendOrderItemsString += "<div class='order-item clearfix'><div class='order-item-name col-md-6 " +
                    "col-sm-6 col-xs-6'>" +
                    "<small class='item-code'>" + orderItem.itemCode +"</small><p class='item-description'>" +
                    orderItem.itemName + "</p>" +
                    "</div><div class='col-md-6 col-sm-6 col-xs-6 text-right'><div class='item-price'><span " +
                    "class='badge'>" +
                    "GHS" +" "+ orderItem.unitPrice +"</span></div>" +
                    "<div class='item-qty'><small>x</small>" +orderItem.quantity +
                    "</div><div class='item-subtotal'><small>GHS</small> " + orderItem.subTotal +
                    "</div></div></div>";
            }
            $('#order-item-list2').append(appendOrderItemsString);
        }


//    $('.pay-opt').hide();
        for(var a = 0; a < paymentChannels.length; a++) {
            var payOption = paymentChannels[a];
            if(payOption.name === "MTN Mobile Money") {
                if(payOption.active) {
                    $('#mtn-money-opt').removeClass('disabled');
                }else {
                    $('#mtn-money-opt')[0].setAttribute("data-toggle","tooltip");
                    $('#mtn-money-opt')[0].setAttribute("title", payOption.reason)
                }
            }
            if (payOption.name === "AirtelTigo Money") {
                if(payOption.active) {
                    $('#airtel-money-opt').removeClass('disabled')
                }else {
                    $('#airtel-money-opt')[0].setAttribute("data-toggle","tooltip");
                    $('#airtel-money-opt')[0].setAttribute("title", payOption.reason)
                }
            }
            if(payOption.name === "VISA") {
                if(payOption.active) {
                    $('#visa-opt').removeClass('disabled')
                } else {
                    $('#visa-opt')[0].setAttribute("data-toggle","tooltip");
                    $('#visa-opt')[0].setAttribute("title", payOption.reason)
                }
            }
            if(payOption.name === "Tigo Cash") {
                if(payOption.active) {
                    $('#tigo-cash-opt').removeClass('disabled')
                }else {
                    $('#tigo-cash-opt')[0].setAttribute("data-toggle","tooltip");
                    $('#tigo-cash-opt')[0].setAttribute("title", payOption.reason)
                }
            }
            if(payOption.name === "Vodafone Cash") {
                if(payOption.active) {
                    $('#vodafone-cash-opt').removeClass('disabled')
                }else {
                    $('#vodafone-cash-opt')[0].setAttribute("data-toggle","tooltip");
                    $('#vodafone-cash-opt')[0].setAttribute("title", payOption.reason)
                }
            }
        }

//    OrderFormPage.init();

        var provider = "MTN_MONEY";
        if(provider == "MTN_MONEY") {
            if($('#mtn-money-opt').is(':visible')) {
                $('#pay-with-mtn').click();
            }
        }
        else if(provider == "AIRTEL_MONEY") {
            if($('#airtel-money-opt').is(':visible')) {
                $('#pay-with-airtel').click();
            }
        }
        else if(provider == "VISA") {
            if($('#visa-opt').is(':visible')) {
                $('#pay-with-visa').click();
                document.getElementById("cancel-url-modal").style.display= "inline";
            }
        }
        else if(provider == "TIGO_CASH") {
            if($('#tigo-cash-opt').is(':visible')) {
                $('#pay-with-tigo').click();
            }
        }
        else if(provider == "VODAFONE_CASH") {
            if($('#vodafone-cash-opt').is(':visible')) {
                $('#pay-with-vodafone').click();
            }
        }
//    $('#visa-opt').is(':visible')
    });

    // assign callback url to variable merchantUrl
    function redirect(merchantUrl) {
        $('#redirect-modal').modal();

        $('#redirect-modal').on('shown.bs.modal', function() {
            /*var countDown = new FlipClock($('#redirect-timer'), {
             countdown: true
             });*/
            $('#redirect-timer').countdown({
                until: +5,
                expiryUrl: merchantUrl,
                compact: true,
                format: 'HMS',
                description: ''
            });
        });
    }

    function orderformpageLogin(email, password) {
        $.ajax({
            url: "/paylive/orderform/login",
            data: {email:email, password:password, "" : ""},
            method: "POST", beforeSend: function () {
            },
            success: function (jqXHR) {
                if(jqXHR.status) {
                    emailOrMobile = email;
                    loginResult = jqXHR.result;
                    $('#customer-name').html(loginResult.userName);
                    secretCodeMap = loginResult.secretCodeMap;
                    exServeCode[0] = loginResult.secretCodeMap.code1;
                    exServeCode[1] = loginResult.secretCodeMap.code2;
                    exServeCode[2] = loginResult.secretCodeMap.code3;
                    LoginSec.init();
                    accounts = loginResult.accounts;

                    var user_accounts_string = "";
                    for(i = 0; i < accounts.length; i++) {
                        var account = accounts[i];
//                        J. Anderson [Fidelity Bank Savings]
                        user_accounts_string += "<option value='" + i + "'>" + account.accountName + " [" + account.accountType + "]" + "</option>";
//                        user_accounts
                    }
                    $( 'select[id="user_accounts"]' ).append( user_accounts_string );

                }else{
//                    alert(jqXHR.message);
                    noty({
                        layout: 'top',
                        type: 'error',
                        text: jqXHR.message,
                        timeout: 3000,
                        modal: false
                    });
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                noty({
                    layout: 'top',
                    type: 'error',
                    text: "An error occurred, please try later",
                    timeout: 3000,
                    modal: false
                });
            }
        });
    }

    function generateCallbackUrl(transactionCommonId, isSuccess, isCancel, isError) {
        if ( typeof String.prototype.endsWith != 'function' ) {
            String.prototype.endsWith = function( str ) {
                return this.substring( this.length - str.length, this.length ) === str;
            }
        }
        var callbackUrlString = merchantDetails.callbackURL;
        var extraParams = order.extraParameters;
        var hasparams = true;
        if(callbackUrlString.indexOf("?") <= -1) {
            callbackUrlString += "?";
            hasparams = false;
        }
        if(!callbackUrlString.endsWith("&") && hasparams) {
            callbackUrlString += "&";
        }
        if (extraParams != null && (extraParams != "")) {
            callbackUrlString += extraParams;
            hasparams = true;
        }
        if (!callbackUrlString.endsWith("&") && hasparams) {
            callbackUrlString += "&";
        }
        if (isSuccess) {
            callbackUrlString += "status=0";
        }else if (isCancel){
            callbackUrlString += "status=-2";
        }else if (isError){
            callbackUrlString += "status=-1";
        }

//    callbackUrlString += "status=0";
        callbackUrlString += "&transac_id=" + transactionCommonId;
        callbackUrlString += "&pay_token=" + order.payToken;
        callbackUrlString += "&cust_ref=" + order.merchantInvoiceNumber;
        return callbackUrlString;
    }

    function orderformpagePay() {
//        var l;
        var selectedAccount = accounts[selectedAccountValue];
        var payingAccountId = selectedAccount.accountId;
        var isIwalletAccount = selectedAccount.isIwalletAccount;
        var iwalletOrderId = order.orderId;
        $.ajax({
            url: "/paylive/orderform/pay",
            data:{iwalletOrderId:iwalletOrderId, payingAccountId:payingAccountId, isIwalletAccount:isIwalletAccount,
                secretCode:secretCodeValue, authCode:authCode, emailOrMobile:emailOrMobile,
                "" : ""},
            method: "POST", beforeSend: function () {
//                l= Ladda.create(el);
//                l.start();
            },
            success: function (jqXHR) {
//                l.stop();
                if(jqXHR.status){

                    if(jqXHR.message === "CARD"){
                        $('#visa-modal-link').modal('show');
                        postRequest(jqXHR.result);
                    }

                    ActionAuth.resetCode()
                    $('.auth-modal').modal('hide');
                    if(!isIwalletAccount) {
                        if (selectedAccount.payAccountType === "MOBILE_MONEY_ACCOUNT") {

                            $('#mtn-step1').hide();
                            $('#mtn-step-linked').fadeIn('normal');
                            $('#mtn-modal').modal({
                                keyboard: false,
                                backdrop: 'static'
                            });

                            institutionTransId = jqXHR.message;
                            if (institutionTransId !== null) {
                                checkPaymentStatus()
                            }
                        } else if(selectedAccount.payAccountType === "BANK_ACCOUNT") {
                            noty({
                                layout: 'top',
                                type: 'success',
                                text: jqXHR.message,
                                timeout: 3000,
                                modal: false
                            });
                            if(order.orderType == "PAY_POINT" || order.orderType == 'BILLING') {
                                redirect(jqXHR.result)
                            } else {
                                if (typeof jqXHR.result === "string") {
                                    redirect(decodeURIComponent(jqXHR.result))
                                } else {
                                    redirect(generateCallbackUrl(jqXHR.result.commonId, true, false,false));
                                }
                            }
                        } else {
                            var url = jqXHR.result;
                            if (url.indexOf("www.i-walletlive.com/") > -1) {
                                url = url.replace("www.i-walletlive.com", "app.slydepay.com")
                            }
                            $('#visa-step-link-card iframe').attr('src', url);
                            $('#visa-modal-link').modal('show');
                        }
                    } else {
                        noty({
                            layout: 'top',
                            type: 'success',
                            text: jqXHR.message,
                            timeout: 3000,
                            modal: false
                        });
                        if(order.orderType == "PAY_POINT" || order.orderType == 'BILLING') {
                            redirect(jqXHR.result)
                        } else {
                            if (typeof jqXHR.result === "string") {
                                redirect(decodeURIComponent(jqXHR.result))
                            } else {
                                redirect(generateCallbackUrl(jqXHR.result.commonId, true, false,false));
                            }
                        }

//                    redirect(jqXHR.result);
                    }


//                    window.location.replace(jqXHR.result);
                }else {
                    $('.auth-modal').modal('hide');
                    noty({
                        layout: 'top',
                        type: 'error',
                        text: jqXHR.message,
                        timeout: 3000,
                        modal: false
                    });
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                $('.auth-modal').modal('hide');
                noty({
                    layout: 'top',
                    type: 'error',
                    text: "An error occurred, please try later",
                    timeout: 3000,
                    modal: false
                });
            }
        });



    }

    function postRequest(parameters){
        var my_form;
        my_form=document.createElement('FORM');
        my_form.name='Card Processor';
        my_form.title='Card Processor';
        my_form.method='POST';
        my_form.action=cardProcessingUrl;
        my_form.target="card_iframe";

        my_form.appendChild(getFormElement("accessCode",parameters.accessCode));
        my_form.appendChild(getFormElement("amount",parameters.amount));
        my_form.appendChild(getFormElement("cardExp",parameters.cardExp));
        my_form.appendChild(getFormElement("cardNum",parameters.cardNum));
        my_form.appendChild(getFormElement("cardSecurityCode",parameters.cardSecurityCode));
        my_form.appendChild(getFormElement("command",parameters.command));
        my_form.appendChild(getFormElement("currency",parameters.currency));
        my_form.appendChild(getFormElement("gateway",parameters.gateway));
        my_form.appendChild(getFormElement("merchTxnRef",parameters.merchTxnRef));
        my_form.appendChild(getFormElement("merchant",parameters.merchant));
        my_form.appendChild(getFormElement("orderInfo",parameters.orderInfo));
        my_form.appendChild(getFormElement("returnUrl",parameters.returnUrl));
        my_form.appendChild(getFormElement("version",parameters.version));
        my_form.appendChild(getFormElement("card",parameters.card));
        my_form.appendChild(getFormElement("secureHash",parameters.secureHash));
        my_form.appendChild(getFormElement("secureHashType",parameters.secureHashType));
        my_form.appendChild(getFormElement("hashedPan",parameters.hashedPan));
        my_form.appendChild(getFormElement("twoPartyProcessing",parameters.twoPartyProcessing));
        my_form.appendChild(getFormElement("receiptUrl",parameters.receiptUrl));



        document.body.appendChild(my_form);
        my_form.submit();
    }

    function getFormElement(name,url){

//		var value = getParameterByName(name,url);

        var my_tb=document.createElement('INPUT');
        my_tb.type='TEXT';
        my_tb.name=name;
        my_tb.value=url;
        my_tb.setAttribute("type", "hidden");


        return my_tb;
    }

</script>



<script type="text/javascript">window.NREUM||(NREUM={});NREUM.info={"errorBeacon":"bam.nr-data.net","licenseKey":"e4d65cd08f","agent":"","beacon":"bam.nr-data.net","applicationTime":36,"applicationID":"69318803","transactionName":"YQRaY0UEV0NTVkNbDFhOa0dFDFdXcVpZRhFZDVRSRUpJUUtZXkQGGQVdQ1YMVUNcUEAcAkURQBcfInxkGw==","queueTime":0}</script><script async type="text/javascript" src="/_Incapsula_Resource?SWJIYLWA=719d34d31c8e3a6e6fffd425f7e032f3&ns=1&cb=1753159728"></script>
</body>

</html>
